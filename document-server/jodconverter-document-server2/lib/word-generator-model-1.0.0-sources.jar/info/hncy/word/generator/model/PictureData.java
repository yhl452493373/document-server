package info.hncy.word.generator.model;

import javax.imageio.ImageIO;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;

/**
 * 图片数据封装 —— 支持多种图片来源和尺寸控制，类似 poi-tl 的 PictureRenderData。
 *
 * <p>图片来源：</p>
 * <ul>
 *   <li>{@code byte[]} — PNG/JPEG 字节数组</li>
 *   <li>{@code String} — 本地文件路径（如 {@code "sign.png"}）</li>
 *   <li>{@link File} — 本地图片文件</li>
 *   <li>{@link Image} / {@link BufferedImage} — Java 图片对象</li>
 *   <li>{@code URL} / 网络地址 — 远程图片</li>
 * </ul>
 *
 * <p>尺寸控制（优先级：宽/高 > 缩放比例 > 原图大小）：</p>
 * <ul>
 *   <li>{@link #size(int, int)} — 绝对宽高（像素，强制拉伸）</li>
 *   <li>{@link #width(int)} — 只设宽度，高度按原图比例自动算</li>
 *   <li>{@link #height(int)} — 只设高度，宽度按原图比例自动算</li>
 *   <li>{@link #scale(double)} — 等比缩放（如 0.5 = 50%）</li>
 *   <li>不设 — 使用图片原始大小</li>
 * </ul>
 *
 * <p>用法示例：</p>
 * <pre>
 * // 从路径加载，只设宽度（高度按比例）
 * PictureData.of("sign.png").width(200)
 *
 * // 从文件加载，设置绝对尺寸
 * PictureData.of(new File("sign.png")).size(200, 80)
 *
 * // 从网络加载，缩放 50%
 * PictureData.ofUrl("https://example.com/logo.png").scale(0.5)
 * </pre>
 */
public class PictureData {

    /** 像素到 EMU 的转换常量（96 DPI 下 1px = 9525 EMU） */
    private static final int PX_TO_EMU = 9525;

    /** 图片二进制数据 */
    private final byte[] imageBytes;

    /** 图片格式后缀（如 "png"、"jpeg"），影响 docx 包内文件名 */
    private String format = "png";

    /** 自定义宽度（像素），null 表示不设置 */
    private Integer width;

    /** 自定义高度（像素），null 表示不设置 */
    private Integer height;

    /** 缩放比例（如 0.5 = 50%），null 表示不缩放 */
    private Double scale;

    /** 缓存解码后的原始尺寸，避免重复解码 */
    private int[] decodedSize;

    private PictureData(byte[] imageBytes) {
        this.imageBytes = imageBytes;
    }

    // ==================== 静态工厂方法 ====================

    /**
     * 从字节数组创建图片数据。
     *
     * @param bytes PNG/JPEG 图片字节数组
     * @return PictureData 实例
     */
    public static PictureData of(byte[] bytes) {
        return new PictureData(bytes);
    }

    /**
     * 从字节数组创建图片数据，并指定格式。
     *
     * @param bytes  图片字节数组
     * @param format 图片格式（如 "png"、"jpeg"），null 默认为 "png"
     * @return PictureData 实例
     */
    public static PictureData of(byte[] bytes, String format) {
        PictureData pd = new PictureData(bytes);
        pd.format = format != null ? format : "png";
        return pd;
    }

    /**
     * 创建空图片数据（用于清除占位符但不插入图片的场景）。
     *
     * @return 空的 PictureData 实例
     */
    public static PictureData empty() {
        return new PictureData(new byte[0]);
    }

    /**
     * 从本地文件路径加载图片。
     *
     * @param path 图片文件路径
     * @return PictureData 实例
     * @throws Exception 文件不存在或读取失败
     */
    public static PictureData of(String path) throws Exception {
        return of(new File(path));
    }

    /**
     * 从本地文件加载图片，自动推断格式。
     *
     * @param file 图片文件
     * @return PictureData 实例
     * @throws Exception 文件不存在或读取失败
     */
    public static PictureData of(File file) throws Exception {
        byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
        PictureData pd = new PictureData(bytes);
        pd.format = inferFormat(file.getName());
        return pd;
    }

    /**
     * 从 Java Image 对象创建图片数据（转为 PNG 格式）。
     *
     * @param image Java 图片对象（Image 或 BufferedImage）
     * @return PictureData 实例
     * @throws Exception 图片转换失败
     */
    public static PictureData of(Image image) throws Exception {
        BufferedImage buffered;
        if (image instanceof BufferedImage) {
            buffered = (BufferedImage) image;
        } else {
            int w = image.getWidth(null);
            int h = image.getHeight(null);
            if (w <= 0 || h <= 0) {
                throw new IllegalArgumentException("图片尺寸无效：" + w + "x" + h);
            }
            buffered = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            java.awt.Graphics g = buffered.getGraphics();
            try {
                g.drawImage(image, 0, 0, null);
            } finally {
                g.dispose();
            }
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if (!ImageIO.write(buffered, "png", baos)) {
            throw new IllegalStateException("无法写入 PNG 图片数据：格式不支持");
        }
        return new PictureData(baos.toByteArray());
    }

    /**
     * 从 URL 加载远程图片，自动推断格式。
     * 默认连接超时 5 秒，读取超时 10 秒。
     *
     * @param url 远程图片 URL 地址
     * @return PictureData 实例
     * @throws Exception 网络请求失败或 URL 无效
     */
    public static PictureData ofUrl(String url) throws Exception {
        return ofUrl(url, 5000, 10000);
    }

    /**
     * 从 URL 加载远程图片，自动推断格式，可指定超时时间。
     *
     * @param url              远程图片 URL 地址
     * @param connectTimeoutMs 连接超时（毫秒），0 表示无限等待
     * @param readTimeoutMs    读取超时（毫秒），0 表示无限等待
     * @return PictureData 实例
     * @throws Exception 网络请求失败或 URL 无效
     */
    public static PictureData ofUrl(String url, int connectTimeoutMs, int readTimeoutMs) throws Exception {
        URL u = new URL(url);
        java.net.URLConnection urlConn = u.openConnection();
        if (!(urlConn instanceof java.net.HttpURLConnection)) {
            throw new IllegalArgumentException("仅支持 http/https 协议的图片 URL，当前协议: " + u.getProtocol());
        }
        java.net.HttpURLConnection conn = (java.net.HttpURLConnection) urlConn;
        conn.setConnectTimeout(connectTimeoutMs);
        conn.setReadTimeout(readTimeoutMs);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (InputStream is = conn.getInputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) != -1) {
                baos.write(buf, 0, n);
            }
        } finally {
            conn.disconnect();
        }
        PictureData pd = new PictureData(baos.toByteArray());
        pd.format = inferFormat(u.getPath());
        return pd;
    }

    // ==================== 链式尺寸设置 ====================

    /**
     * 设置绝对宽高（像素，强制拉伸，不保持比例）。
     *
     * @param width  宽度（像素）
     * @param height 高度（像素）
     * @return 当前实例（支持链式调用）
     */
    public PictureData size(int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("宽高必须大于 0，当前值: " + width + "x" + height);
        }
        this.width = width;
        this.height = height;
        this.scale = null;
        return this;
    }

    /**
     * 只设宽度，高度按原图比例自动计算。
     *
     * @param w 宽度（像素）
     * @return 当前实例（支持链式调用）
     */
    public PictureData width(int w) {
        if (w <= 0) {
            throw new IllegalArgumentException("宽度必须大于 0，当前值: " + w);
        }
        this.width = w;
        this.height = null;
        this.scale = null;
        return this;
    }

    /**
     * 只设高度，宽度按原图比例自动计算。
     *
     * @param h 高度（像素）
     * @return 当前实例（支持链式调用）
     */
    public PictureData height(int h) {
        if (h <= 0) {
            throw new IllegalArgumentException("高度必须大于 0，当前值: " + h);
        }
        this.height = h;
        this.width = null;
        this.scale = null;
        return this;
    }

    /**
     * 等比缩放（如 0.5 = 50%，2.0 = 200%）。
     *
     * @param ratio 缩放比例
     * @return 当前实例（支持链式调用）
     */
    public PictureData scale(double ratio) {
        if (ratio <= 0) {
            throw new IllegalArgumentException("缩放比例必须大于 0，当前值: " + ratio);
        }
        this.scale = ratio;
        this.width = null;
        this.height = null;
        return this;
    }

    /**
     * 设置图片格式后缀（如 "png"、"jpeg"），影响 docx 包内文件名。
     */
    public PictureData format(String format) {
        this.format = format != null ? format : "png";
        return this;
    }

    /**
     * 获取图片二进制数据。
     *
     * @return 图片字节数组
     */
    public byte[] getImageBytes() {
        return imageBytes;
    }

    /**
     * 获取图片格式后缀。
     *
     * @return 格式字符串（如 "png"、"jpeg"）
     */
    public String getFormat() {
        return format;
    }

    /**
     * 获取自定义宽度。
     *
     * @return 宽度（像素），null 表示未设置
     */
    public Integer getWidth() {
        return width;
    }

    /**
     * 获取自定义高度。
     *
     * @return 高度（像素），null 表示未设置
     */
    public Integer getHeight() {
        return height;
    }

    /**
     * 获取缩放比例。
     *
     * @return 缩放比例，null 表示未设置
     */
    public Double getScale() {
        return scale;
    }

    /**
     * 计算最终渲染尺寸（EMU）。固定 96 DPI（9525 EMU/px）。
     *
     * @return long[2]：[cx, cy]，单位 EMU；如果无自定义尺寸则返回 null
     */
    public long[] computeEmuSize() throws Exception {
        if (imageBytes.length == 0) {
            return null;
        }
        if (width != null || height != null) {
            int[] orig = getDecodedSize();
            int origW = orig[0];
            int origH = orig[1];
            int finalW, finalH;
            if (width != null && height != null) {
                finalW = width;
                finalH = height;
            } else if (width != null) {
                finalW = width;
                finalH = (int) ((long) width * origH / origW);
            } else {
                finalH = height;
                finalW = (int) ((long) height * origW / origH);
            }
            return new long[]{ (long) finalW * PX_TO_EMU, (long) finalH * PX_TO_EMU };
        }
        if (scale != null) {
            int[] orig = getDecodedSize();
            int w = Math.max(1, (int) (orig[0] * scale));
            int h = Math.max(1, (int) (orig[1] * scale));
            return new long[]{ (long) w * PX_TO_EMU, (long) h * PX_TO_EMU };
        }
        return null;
    }

    private int[] getDecodedSize() throws Exception {
        if (decodedSize == null) {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
            if (img == null) {
                throw new IllegalArgumentException("无法解码图片数据：格式不支持或数据已损坏");
            }
            if (img.getWidth() <= 0 || img.getHeight() <= 0) {
                throw new IllegalArgumentException("图片尺寸无效：" + img.getWidth() + "x" + img.getHeight());
            }
            decodedSize = new int[]{ img.getWidth(), img.getHeight() };
        }
        return decodedSize;
    }

    /** 从文件名/路径推断图片格式后缀，未知后缀默认 "png" */
    private static String inferFormat(String nameOrPath) {
        if (nameOrPath == null) return "png";
        int dot = nameOrPath.lastIndexOf('.');
        if (dot < 0 || dot == nameOrPath.length() - 1) return "png";
        String ext = nameOrPath.substring(dot + 1).toLowerCase();
        if ("jpg".equals(ext)) ext = "jpeg";
        if ("png".equals(ext) || "jpeg".equals(ext) || "gif".equals(ext)
                || "bmp".equals(ext) || "tiff".equals(ext)) {
            return ext;
        }
        return "png";
    }
}
