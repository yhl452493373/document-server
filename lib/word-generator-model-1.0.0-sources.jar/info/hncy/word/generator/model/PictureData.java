package info.hncy.word.generator.model;

import info.hncy.word.generator.support.PictureLoader;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.Serializable;

/**
 * 图片数据封装 —— 支持多种图片来源和尺寸控制，类似 poi-tl 的 PictureRenderData。
 *
 * <p>使用方式：先通过 {@code of()} 设置来源，链式设置尺寸参数，最后调用 {@link #create()} 完成构建。</p>
 *
 * <p>图片来源：</p>
 * <ul>
 *   <li>{@code byte[]} — PNG/JPEG 字节数组</li>
 *   <li>{@code String} — 本地文件路径（如 {@code "sign.png"}）</li>
 *   <li>{@link File} — 本地图片文件</li>
 *   <li>{@link Image} / {@link BufferedImage} — Java 图片对象</li>
 *   <li>{@code URL} / 网络地址 — 远程图片</li>
 * </ul>
 *
 * <h3>尺寸控制</h3>
 *
 * <p>支持像素和厘米两种单位，厘米通过 96 DPI 标准转换为像素（1 cm ≈ 37.795 px）。</p>
 *
 * <p>四种尺寸模式（互斥，后调用的方法覆盖先前的设置）：</p>
 * <table border="1">
 *   <tr><th>模式</th><th>方法</th><th>行为</th></tr>
 *   <tr>
 *     <td>强制拉伸</td>
 *     <td>{@link #size(int, int)} / {@link #sizeCm(double, double)}</td>
 *     <td>同时设置宽高，不保持宽高比，图片可能被拉伸变形</td>
 *   </tr>
 *   <tr>
 *     <td>定宽等高</td>
 *     <td>{@link #width(int)} / {@link #widthCm(double)}</td>
 *     <td>只设宽度，高度按原图宽高比自动计算，保持比例</td>
 *   </tr>
 *   <tr>
 *     <td>定高等宽</td>
 *     <td>{@link #height(int)} / {@link #heightCm(double)}</td>
 *     <td>只设高度，宽度按原图宽高比自动计算，保持比例</td>
 *   </tr>
 *   <tr>
 *     <td>等比缩放</td>
 *     <td>{@link #scale(double)}</td>
 *     <td>按原图尺寸等比缩放（如 0.5 = 缩小 50%）</td>
 *   </tr>
 * </table>
 *
 * <p><b>优先级：</b>宽/高设定 &gt; 缩放比例 &gt; 原图大小。不调用任何尺寸方法则使用图片原始尺寸。</p>
 *
 * <p><b>互斥规则：</b>每次调用尺寸方法会清除之前设置的值。
 * 例如先调用 {@code width(200)} 再调用 {@code scale(0.5)}，最终生效的是 scale，width 被清除。</p>
 *
 * <p>用法示例：</p>
 * <pre>
 * // 强制拉伸到指定像素
 * PictureData.of("sign.png").size(200, 80).create()
 *
 * // 强制拉伸到指定厘米
 * PictureData.of("sign.png").sizeCm(3.0, 1.5).create()
 *
 * // 只设宽度（厘米），高度按比例
 * PictureData.of("logo.png").widthCm(5.0).create()
 *
 * // 只设高度（像素），宽度按比例
 * PictureData.of("photo.jpg").height(300).create()
 *
 * // 等比缩放 50%
 * PictureData.ofUrl("https://example.com/logo.png").scale(0.5).create()
 *
 * // 从字节数组创建（数据已在内存中，create 仅标记构建完成）
 * PictureData.of(pngBytes).size(120, 50).create()
 * </pre>
 *
 * @see PictureLoader
 */
public class PictureData implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 厘米到像素的转换系数（96 DPI / 2.54 cm/inch ≈ 37.795） */
    private static final double CM_TO_PX = 96.0 / 2.54;

    /** 图片的二进制数据 */
    private byte[] imageBytes;

    /** 图片格式（"png"、"jpeg" 等） */
    private String format = "png";

    /** 目标宽度（像素） */
    private Integer width;

    /** 目标高度（像素） */
    private Integer height;

    /** 缩放比例 */
    private Double scale;

    /** 延迟加载的图片来源 */
    private transient Object source;

    /** 来源类型，取值见 {@link PictureLoader#SOURCE_PATH} 等常量 */
    private transient int sourceType;

    /** 网络来源连接超时（毫秒） */
    private transient int connectTimeoutMs;

    /** 网络来源读取超时（毫秒） */
    private transient int readTimeoutMs;

    private PictureData() {}

    // ==================== 静态工厂方法 ====================

    /**
     * 从字节数组创建图片数据。
     *
     * @param bytes PNG/JPEG 图片字节数组
     * @return PictureData 实例（已加载，create() 为 no-op）
     */
    public static PictureData of(byte[] bytes) {
        PictureData pd = new PictureData();
        pd.imageBytes = bytes;
        return pd;
    }

    /**
     * 从字节数组创建图片数据，并指定格式。
     *
     * @param bytes  图片字节数组
     * @param format 图片格式，null 默认为 "png"
     * @return PictureData 实例
     */
    public static PictureData of(byte[] bytes, String format) {
        PictureData pd = of(bytes);
        pd.format = format != null ? format : "png";
        return pd;
    }

    /**
     * 创建空图片数据（用于清除占位符但不插入图片的场景）。
     *
     * @return 空的 PictureData 实例
     */
    public static PictureData empty() {
        return of(new byte[0]);
    }

    /**
     * 从本地文件路径创建图片数据（延迟加载）。
     *
     * @param path 图片文件路径
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData of(String path) {
        PictureData pd = new PictureData();
        pd.source = path;
        pd.sourceType = PictureLoader.SOURCE_PATH;
        return pd;
    }

    /**
     * 从本地文件创建图片数据（延迟加载）。
     *
     * @param file 图片文件
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData of(File file) {
        PictureData pd = new PictureData();
        pd.source = file;
        pd.sourceType = PictureLoader.SOURCE_FILE;
        return pd;
    }

    /**
     * 从 Java Image 对象创建图片数据（延迟加载）。
     *
     * @param image Java 图片对象
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData of(Image image) {
        PictureData pd = new PictureData();
        pd.source = image;
        pd.sourceType = PictureLoader.SOURCE_IMAGE;
        return pd;
    }

    /**
     * 从 URL 创建远程图片数据（延迟加载），默认超时 5s/10s。
     *
     * @param url 远程图片 URL
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData ofUrl(String url) {
        return ofUrl(url, 5000, 10000);
    }

    /**
     * 从 URL 创建远程图片数据（延迟加载），可指定超时。
     *
     * @param url              远程图片 URL
     * @param connectTimeoutMs 连接超时（毫秒）
     * @param readTimeoutMs    读取超时（毫秒）
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData ofUrl(String url, int connectTimeoutMs, int readTimeoutMs) {
        PictureData pd = new PictureData();
        pd.source = url;
        pd.sourceType = PictureLoader.SOURCE_URL;
        pd.connectTimeoutMs = connectTimeoutMs;
        pd.readTimeoutMs = readTimeoutMs;
        return pd;
    }

    // ==================== 链式尺寸设置 ====================

    /**
     * 设置绝对宽高（像素，强制拉伸）。
     *
     * @param width  宽度（像素）
     * @param height 高度（像素）
     * @return 当前实例
     */
    public PictureData size(int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("宽高必须大于 0");
        }
        this.width = width;
        this.height = height;
        this.scale = null;
        return this;
    }

    /**
     * 设置绝对宽高（厘米，强制拉伸）。
     *
     * @param widthCm  宽度（厘米）
     * @param heightCm 高度（厘米）
     * @return 当前实例
     */
    public PictureData sizeCm(double widthCm, double heightCm) {
        if (widthCm <= 0 || heightCm <= 0) {
            throw new IllegalArgumentException("宽高必须大于 0");
        }
        this.width = (int) Math.round(widthCm * CM_TO_PX);
        this.height = (int) Math.round(heightCm * CM_TO_PX);
        this.scale = null;
        return this;
    }

    /**
     * 只设宽度（像素），高度按比例计算。
     *
     * @param w 宽度（像素）
     * @return 当前实例
     */
    public PictureData width(int w) {
        if (w <= 0) throw new IllegalArgumentException("宽度必须大于 0");
        this.width = w;
        this.height = null;
        this.scale = null;
        return this;
    }

    /**
     * 只设宽度（厘米），高度按比例计算。
     *
     * @param cm 宽度（厘米）
     * @return 当前实例
     */
    public PictureData widthCm(double cm) {
        if (cm <= 0) throw new IllegalArgumentException("宽度必须大于 0");
        this.width = (int) Math.round(cm * CM_TO_PX);
        this.height = null;
        this.scale = null;
        return this;
    }

    /**
     * 只设高度（像素），宽度按比例计算。
     *
     * @param h 高度（像素）
     * @return 当前实例
     */
    public PictureData height(int h) {
        if (h <= 0) throw new IllegalArgumentException("高度必须大于 0");
        this.height = h;
        this.width = null;
        this.scale = null;
        return this;
    }

    /**
     * 只设高度（厘米），宽度按比例计算。
     *
     * @param cm 高度（厘米）
     * @return 当前实例
     */
    public PictureData heightCm(double cm) {
        if (cm <= 0) throw new IllegalArgumentException("高度必须大于 0");
        this.height = (int) Math.round(cm * CM_TO_PX);
        this.width = null;
        this.scale = null;
        return this;
    }

    /**
     * 等比缩放（如 0.5 = 50%）。
     *
     * @param ratio 缩放比例
     * @return 当前实例
     */
    public PictureData scale(double ratio) {
        if (ratio <= 0) throw new IllegalArgumentException("缩放比例必须大于 0");
        this.scale = ratio;
        this.width = null;
        this.height = null;
        return this;
    }

    /**
     * 设置图片格式。
     *
     * @param format 格式，null 默认为 "png"
     * @return 当前实例
     */
    public PictureData format(String format) {
        this.format = format != null ? format : "png";
        return this;
    }

    // ==================== 构建与访问 ====================

    /**
     * 完成构建：委托 {@link PictureLoader} 触发图片数据加载。幂等操作。
     *
     * @return 当前实例
     * @throws IllegalStateException 如果加载失败
     */
    public PictureData create() {
        if (imageBytes == null && source != null) {
            try {
                PictureLoader.LoadResult result = PictureLoader.load(source, sourceType, connectTimeoutMs, readTimeoutMs);
                imageBytes = result.bytes;
                format = result.format;
            } catch (Exception e) {
                throw new IllegalStateException("图片加载失败: " + e.getMessage(), e);
            } finally {
                source = null;
            }
        }
        return this;
    }

    /** 获取图片二进制数据（自动触发加载） */
    public byte[] getImageBytes() {
        create();
        return imageBytes;
    }

    /** 获取图片格式 */
    public String getFormat() { return format; }

    /** 获取设置的宽度，未设置返回 null */
    public Integer getWidth() { return width; }

    /** 获取设置的高度，未设置返回 null */
    public Integer getHeight() { return height; }

    /** 获取设置的缩放比例，未设置返回 null */
    public Double getScale() { return scale; }
}
