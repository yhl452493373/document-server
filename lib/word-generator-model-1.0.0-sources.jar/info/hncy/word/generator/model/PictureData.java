package info.hncy.word.generator.model;

import info.hncy.word.generator.support.PictureLoader;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.Serializable;

/**
 * 图片数据封装 —— 支持多种图片来源和尺寸控制，类似 poi-tl 的 PictureRenderData。
 *
 * <p>使用方式：先通过 {@code of()} 设置来源，链式设置尺寸参数，最后调用 {@link #create()} 完成构建。</p>
 *
 * <p>图片来源：</p>
 * <ul>
 *   <li>{@code byte[]} — PNG/JPEG 字节数组</li>
 *   <li>{@code String} — 本地文件路径（如 {@code "sign.png"}）</li>
 *   <li>{@link File} — 本地图片文件</li>
 *   <li>{@link Image} / {@link BufferedImage} — Java 图片对象</li>
 *   <li>{@code URL} / 网络地址 — 远程图片</li>
 * </ul>
 *
 * <p>尺寸控制（优先级：宽/高 > 缩放比例 > 原图大小）：</p>
 * <ul>
 *   <li>{@link #size(int, int)} — 绝对宽高（像素，强制拉伸）</li>
 *   <li>{@link #width(int)} — 只设宽度，高度按原图比例自动算</li>
 *   <li>{@link #height(int)} — 只设高度，宽度按原图比例自动算</li>
 *   <li>{@link #scale(double)} — 等比缩放（如 0.5 = 50%）</li>
 *   <li>不设 — 使用图片原始大小</li>
 * </ul>
 *
 * <p>用法示例：</p>
 * <pre>
 * // 从路径加载，只设宽度（高度按比例）
 * PictureData.of("sign.png").width(200).create()
 *
 * // 从文件加载，设置绝对尺寸
 * PictureData.of(new File("sign.png")).size(200, 80).create()
 *
 * // 从网络加载，缩放 50%
 * PictureData.ofUrl("https://example.com/logo.png").scale(0.5).create()
 *
 * // 从字节数组创建（数据已在内存中，create 仅标记构建完成）
 * PictureData.of(pngBytes).size(120, 50).create()
 * </pre>
 *
 * @see PictureLoader
 */
public class PictureData implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 图片的二进制数据 */
    private byte[] imageBytes;

    /** 图片格式（"png"、"jpeg" 等） */
    private String format = "png";

    /** 目标宽度（像素） */
    private Integer width;

    /** 目标高度（像素） */
    private Integer height;

    /** 缩放比例 */
    private Double scale;

    /** 延迟加载的图片来源 */
    private transient Object source;

    /** 来源类型，取值见 {@link PictureLoader#SOURCE_PATH} 等常量 */
    private transient int sourceType;

    /** 网络来源连接超时（毫秒） */
    private transient int connectTimeoutMs;

    /** 网络来源读取超时（毫秒） */
    private transient int readTimeoutMs;

    private PictureData() {}

    // ==================== 静态工厂方法 ====================

    /**
     * 从字节数组创建图片数据。
     *
     * @param bytes PNG/JPEG 图片字节数组
     * @return PictureData 实例（已加载，create() 为 no-op）
     */
    public static PictureData of(byte[] bytes) {
        PictureData pd = new PictureData();
        pd.imageBytes = bytes;
        return pd;
    }

    /**
     * 从字节数组创建图片数据，并指定格式。
     *
     * @param bytes  图片字节数组
     * @param format 图片格式，null 默认为 "png"
     * @return PictureData 实例
     */
    public static PictureData of(byte[] bytes, String format) {
        PictureData pd = of(bytes);
        pd.format = format != null ? format : "png";
        return pd;
    }

    /**
     * 创建空图片数据（用于清除占位符但不插入图片的场景）。
     *
     * @return 空的 PictureData 实例
     */
    public static PictureData empty() {
        return of(new byte[0]);
    }

    /**
     * 从本地文件路径创建图片数据（延迟加载）。
     *
     * @param path 图片文件路径
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData of(String path) {
        PictureData pd = new PictureData();
        pd.source = path;
        pd.sourceType = PictureLoader.SOURCE_PATH;
        return pd;
    }

    /**
     * 从本地文件创建图片数据（延迟加载）。
     *
     * @param file 图片文件
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData of(File file) {
        PictureData pd = new PictureData();
        pd.source = file;
        pd.sourceType = PictureLoader.SOURCE_FILE;
        return pd;
    }

    /**
     * 从 Java Image 对象创建图片数据（延迟加载）。
     *
     * @param image Java 图片对象
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData of(Image image) {
        PictureData pd = new PictureData();
        pd.source = image;
        pd.sourceType = PictureLoader.SOURCE_IMAGE;
        return pd;
    }

    /**
     * 从 URL 创建远程图片数据（延迟加载），默认超时 5s/10s。
     *
     * @param url 远程图片 URL
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData ofUrl(String url) {
        return ofUrl(url, 5000, 10000);
    }

    /**
     * 从 URL 创建远程图片数据（延迟加载），可指定超时。
     *
     * @param url              远程图片 URL
     * @param connectTimeoutMs 连接超时（毫秒）
     * @param readTimeoutMs    读取超时（毫秒）
     * @return PictureData 实例（需调用 create()）
     */
    public static PictureData ofUrl(String url, int connectTimeoutMs, int readTimeoutMs) {
        PictureData pd = new PictureData();
        pd.source = url;
        pd.sourceType = PictureLoader.SOURCE_URL;
        pd.connectTimeoutMs = connectTimeoutMs;
        pd.readTimeoutMs = readTimeoutMs;
        return pd;
    }

    // ==================== 链式尺寸设置 ====================

    /**
     * 设置绝对宽高（像素，强制拉伸）。
     *
     * @param width  宽度
     * @param height 高度
     * @return 当前实例
     */
    public PictureData size(int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("宽高必须大于 0");
        }
        this.width = width;
        this.height = height;
        this.scale = null;
        return this;
    }

    /**
     * 只设宽度，高度按比例计算。
     *
     * @param w 宽度
     * @return 当前实例
     */
    public PictureData width(int w) {
        if (w <= 0) throw new IllegalArgumentException("宽度必须大于 0");
        this.width = w;
        this.height = null;
        this.scale = null;
        return this;
    }

    /**
     * 只设高度，宽度按比例计算。
     *
     * @param h 高度
     * @return 当前实例
     */
    public PictureData height(int h) {
        if (h <= 0) throw new IllegalArgumentException("高度必须大于 0");
        this.height = h;
        this.width = null;
        this.scale = null;
        return this;
    }

    /**
     * 等比缩放（如 0.5 = 50%）。
     *
     * @param ratio 缩放比例
     * @return 当前实例
     */
    public PictureData scale(double ratio) {
        if (ratio <= 0) throw new IllegalArgumentException("缩放比例必须大于 0");
        this.scale = ratio;
        this.width = null;
        this.height = null;
        return this;
    }

    /**
     * 设置图片格式。
     *
     * @param format 格式，null 默认为 "png"
     * @return 当前实例
     */
    public PictureData format(String format) {
        this.format = format != null ? format : "png";
        return this;
    }

    // ==================== 构建与访问 ====================

    /**
     * 完成构建：委托 {@link PictureLoader} 触发图片数据加载。幂等操作。
     *
     * @return 当前实例
     * @throws IllegalStateException 如果加载失败
     */
    public PictureData create() {
        if (imageBytes == null && source != null) {
            try {
                PictureLoader.LoadResult result = PictureLoader.load(source, sourceType, connectTimeoutMs, readTimeoutMs);
                imageBytes = result.bytes;
                format = result.format;
            } catch (Exception e) {
                throw new IllegalStateException("图片加载失败: " + e.getMessage(), e);
            } finally {
                source = null;
            }
        }
        return this;
    }

    /** 获取图片二进制数据（自动触发加载） */
    public byte[] getImageBytes() {
        create();
        return imageBytes;
    }

    /** 获取图片格式 */
    public String getFormat() { return format; }

    /** 获取设置的宽度，未设置返回 null */
    public Integer getWidth() { return width; }

    /** 获取设置的高度，未设置返回 null */
    public Integer getHeight() { return height; }

    /** 获取设置的缩放比例，未设置返回 null */
    public Double getScale() { return scale; }
}
