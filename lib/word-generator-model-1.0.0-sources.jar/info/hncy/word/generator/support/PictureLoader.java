package info.hncy.word.generator.support;

import javax.imageio.ImageIO;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/**
 * 图片加载器 —— 从不同来源加载图片字节数据。
 *
 * <p><b>内部 API</b>：仅供 {@link info.hncy.word.generator.model.PictureData} 调用，
 * 不建议外部直接使用，后续版本可能变更。</p>
 *
 * <p>只负责"获取图片数据"这一件事，不涉及尺寸计算或渲染逻辑。</p>
 *
 * @see info.hncy.word.generator.model.PictureData
 */
public class PictureLoader {

    /** 来源类型：本地文件路径（String） */
    public static final int SOURCE_PATH = 1;

    /** 来源类型：本地文件（File） */
    public static final int SOURCE_FILE = 2;

    /** 来源类型：Java 图片对象（Image / BufferedImage） */
    public static final int SOURCE_IMAGE = 3;

    /** 来源类型：网络 URL（String） */
    public static final int SOURCE_URL = 4;

    private PictureLoader() {}

    /**
     * 加载结果：图片字节数据 + 推断的格式。
     */
    public static class LoadResult {
        /** 图片字节数据 */
        public final byte[] bytes;
        /** 推断的图片格式 */
        public final String format;

        /**
         * 构造加载结果。
         *
         * @param bytes  图片字节数据
         * @param format 图片格式
         */
        public LoadResult(byte[] bytes, String format) {
            this.bytes = bytes;
            this.format = format;
        }
    }

    /**
     * 根据来源类型加载图片数据并推断格式。
     *
     * @param source      图片来源对象
     * @param sourceType  来源类型常量
     * @param connTimeout 连接超时（毫秒，仅 URL 来源）
     * @param readTimeout 读取超时（毫秒，仅 URL 来源）
     * @return 加载结果
     * @throws Exception 如果加载失败
     */
    public static LoadResult load(Object source, int sourceType, int connTimeout, int readTimeout) throws Exception {
        switch (sourceType) {
            case SOURCE_PATH: {
                String path = (String) source;
                byte[] bytes = java.nio.file.Files.readAllBytes(new File(path).toPath());
                return new LoadResult(bytes, inferFormat(path));
            }
            case SOURCE_FILE: {
                File file = (File) source;
                byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
                return new LoadResult(bytes, inferFormat(file.getName()));
            }
            case SOURCE_IMAGE: {
                byte[] bytes = imageToBytes((Image) source);
                return new LoadResult(bytes, "png");
            }
            case SOURCE_URL: {
                String url = (String) source;
                byte[] bytes = loadFromUrl(url, connTimeout, readTimeout);
                return new LoadResult(bytes, inferFormat(url));
            }
            default:
                throw new IllegalStateException("无有效的图片来源");
        }
    }

    /**
     * 将 Java Image 对象转换为 PNG 字节数组。
     *
     * @param image Java 图片对象
     * @return PNG 格式字节数组
     * @throws Exception 如果转换失败
     */
    private static byte[] imageToBytes(Image image) throws Exception {
        BufferedImage buffered;
        if (image instanceof BufferedImage) {
            buffered = (BufferedImage) image;
        } else {
            int w = image.getWidth(null);
            int h = image.getHeight(null);
            if (w <= 0 || h <= 0) {
                throw new IllegalArgumentException("图片尺寸无效：" + w + "x" + h);
            }
            buffered = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            Graphics g = buffered.getGraphics();
            try {
                g.drawImage(image, 0, 0, null);
            } finally {
                g.dispose();
            }
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if (!ImageIO.write(buffered, "png", baos)) {
            throw new IllegalStateException("无法写入 PNG 图片数据");
        }
        return baos.toByteArray();
    }

    /**
     * 从 HTTP/HTTPS URL 下载图片数据。
     *
     * @param url         远程图片地址
     * @param connTimeout 连接超时（毫秒）
     * @param readTimeout 读取超时（毫秒）
     * @return 图片字节数组
     * @throws Exception 如果下载失败
     */
    private static byte[] loadFromUrl(String url, int connTimeout, int readTimeout) throws Exception {
        URL u = new URL(url);
        URLConnection urlConn = u.openConnection();
        if (!(urlConn instanceof HttpURLConnection)) {
            throw new IllegalArgumentException("仅支持 http/https 协议，当前: " + u.getProtocol());
        }
        HttpURLConnection conn = (HttpURLConnection) urlConn;
        conn.setConnectTimeout(connTimeout);
        conn.setReadTimeout(readTimeout);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (InputStream is = conn.getInputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) != -1) {
                baos.write(buf, 0, n);
            }
        } finally {
            conn.disconnect();
        }
        return baos.toByteArray();
    }

    /**
     * 根据文件名后缀推断图片格式。
     *
     * @param nameOrPath 文件名或路径
     * @return 格式字符串（小写），无法识别时默认 "png"
     */
    private static String inferFormat(String nameOrPath) {
        if (nameOrPath == null) return "png";
        int dot = nameOrPath.lastIndexOf('.');
        if (dot < 0 || dot == nameOrPath.length() - 1) return "png";
        String ext = nameOrPath.substring(dot + 1).toLowerCase();
        if ("jpg".equals(ext)) ext = "jpeg";
        if ("png".equals(ext) || "jpeg".equals(ext) || "gif".equals(ext)
                || "bmp".equals(ext) || "tiff".equals(ext)) {
            return ext;
        }
        return "png";
    }
}
