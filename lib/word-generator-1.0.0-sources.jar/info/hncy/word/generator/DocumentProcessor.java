package info.hncy.word.generator;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;

/**
 * 文档处理器统一接口。
 *
 * <p>所有处理器实现此接口后，可按顺序组装成处理管线（pipeline），
 * 由 {@link WordGenerator} 统一调度执行。</p>
 *
 * <p>执行顺序由管线中的添加顺序决定，处理器之间通过 {@link ProcessingContext} 共享数据。</p>
 */
public interface DocumentProcessor {

    /**
     * 对文档包执行处理。
     *
     * @param pkg     文档包
     * @param context 处理上下文（包含文本数据、图片池等共享状态）
     */
    void process(WordprocessingMLPackage pkg, ProcessingContext context) throws Exception;
}
