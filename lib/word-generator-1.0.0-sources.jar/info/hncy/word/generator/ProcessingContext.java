package info.hncy.word.generator;

import info.hncy.word.generator.model.PictureData;

import java.awt.Image;
import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 处理管线中各处理器共享的上下文。
 *
 * <p>构造时接收一份原始数据 Map，自动完成以下处理：</p>
 * <ol>
 *   <li><b>展平嵌套 Map</b>：将 {@code {"caseInfo": {"name": "张三"}}} 展平为
 *       {@code {"caseInfo.name": "张三"}}，支持多级嵌套。</li>
 *   <li><b>分离数据</b>：将图片类型（{@link PictureData}、{@code byte[]}、
 *       {@link Image}、{@link File}）分离到 {@code images} 池，其余放入 {@code others}。</li>
 * </ol>
 *
 * <p>处理器通过 {@link #getImages()} 和 {@link #getOthers()} 分别获取图片和文本数据。</p>
 *
 * @see DocumentProcessor
 * @see DocumentPipeline
 */
public class ProcessingContext {

    /** 图片数据池：key → PictureData */
    private final Map<String, PictureData> images;

    /** 非图片数据池：key → String/Number/Boolean/Map/List 等 */
    private final Map<String, Object> others;

    /** 原始未展平数据（供 BlockPairProcessor 按嵌套结构查找 Map/List 值） */
    private final Map<String, Object> originalData;

    /** 列表展开默认分隔符（由 WordGenerator 设置） */
    private String separator;

    /**
     * 接收原始数据，自动展平嵌套 Map 并分离图片和非图片数据。
     *
     * @param data 原始填充数据（可为 null，此时上下文为空）
     */
    public ProcessingContext(Map<String, Object> data) {
        this.images = new LinkedHashMap<String, PictureData>();
        this.others = new LinkedHashMap<String, Object>();
        this.originalData = data != null ? new LinkedHashMap<String, Object>(data) : new LinkedHashMap<String, Object>();
        if (data != null) {
            splitData(flattenMap("", data));
        }
    }

    /**
     * 展平嵌套 Map，将多层嵌套的 key 用点号连接。
     *
     * <p>例如：{@code {"a": {"b": "c"}}} → {@code {"a.b": "c"}}。
     * 支持任意层级嵌套。</p>
     *
     * @param prefix 当前 key 前缀（顶层调用时传空字符串）
     * @param source 待展平的 Map
     * @return 展平后的单级 Map
     */
    @SuppressWarnings("unchecked")
    private static Map<String, Object> flattenMap(String prefix, Map<String, Object> source) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        for (Map.Entry<String, Object> entry : source.entrySet()) {
            String key = prefix.isEmpty() ? entry.getKey() : prefix + "." + entry.getKey();
            Object val = entry.getValue();
            if (val instanceof Map) {
                out.putAll(flattenMap(key, (Map<String, Object>) val));
            } else {
                out.put(key, val);
            }
        }
        return out;
    }

    /**
     * 将展平后的数据按类型分离到 images 和 others 两个池。
     *
     * <p>图片类型包括：{@link PictureData}、{@code byte[]}、{@link Image}、{@link File}。
     * null 值仅放入 others 池，不创建空图片（让占位符保留在文档中）。</p>
     *
     * @param data 展平后的数据
     * @throws IllegalArgumentException 如果图片数据解析失败
     */
    private void splitData(Map<String, Object> data) {
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            String key = entry.getKey();
            Object val = entry.getValue();
            try {
                if (val instanceof PictureData) {
                    images.put(key, (PictureData) val);
                } else if (val instanceof byte[]) {
                    byte[] bytes = (byte[]) val;
                    images.put(key, bytes.length == 0
                            ? PictureData.empty() : PictureData.of(bytes));
                } else if (val instanceof Image) {
                    images.put(key, PictureData.of((Image) val));
                } else if (val instanceof File) {
                    images.put(key, PictureData.of((File) val));
                } else {
                    others.put(key, val);
                }
            } catch (Exception e) {
                throw new IllegalArgumentException("图片数据解析失败 [" + key + "]: " + e.getMessage(), e);
            }
        }
    }

    /**
     * 获取图片数据池。
     *
     * <p>返回的映射是可修改的，处理器在循环展开时可向其中添加新图片。</p>
     *
     * @return key → PictureData 映射
     */
    public Map<String, PictureData> getImages() {
        return images;
    }

    /**
     * 获取非图片数据池。
     *
     * @return key → Object 映射（包含 String、Number、Boolean、Map、List 等）
     */
    public Map<String, Object> getOthers() {
        return others;
    }

    /**
     * 获取原始未展平的数据。
     *
     * <p>与 {@link #getOthers()} 不同，此方法返回的数据保留了原始嵌套结构，
     * 用于区块对处理器按标签名查找 Map/List 类型的值。</p>
     *
     * @return 原始数据映射
     */
    public Map<String, Object> getOriginalData() {
        return originalData;
    }

    /**
     * 获取列表展开默认分隔符。
     *
     * @return 分隔符，null 表示使用内置的「、」
     */
    public String getSeparator() {
        return separator;
    }

    /**
     * 设置列表展开默认分隔符。
     *
     * @param separator 分隔符，null 表示使用内置的「、」
     */
    public void setSeparator(String separator) {
        this.separator = separator;
    }
}
