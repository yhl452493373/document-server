package info.hncy.word.generator;

import info.hncy.word.generator.support.PlaceholderCleaner;
import info.hncy.word.generator.support.TemplateExtractor;
import info.hncy.word.generator.support.TemplateLoader;
import info.hncy.word.generator.model.PictureData;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Map;
import java.util.Set;

/**
 * 文档生成统一入口。
 *
 * <p>封装完整处理管线：加载模板 → 整理 run → 区块对 → 列表展开 → 变量替换 → 图片替换 → 序列化。</p>
 *
 * <p>三种模板输入方式：</p>
 * <ul>
 *   <li>{@code byte[]} — 模板字节数组（如从网络/数据库读取）</li>
 *   <li>{@link File} — 模板文件对象</li>
 *   <li>{@link String} — 模板文件路径</li>
 * </ul>
 *
 * <p>默认用法（静态方法）：</p>
 * <pre>
 * byte[] result = WordGenerator.generateWord(templateBytes, data);
 * </pre>
 *
 * <p>自定义配置（通过构造函数）：</p>
 * <pre>
 * byte[] result = new WordGenerator(", ").generate(templateBytes, data);
 * </pre>
 *
 * <p>不可变对象，可安全注册为 Spring 单例 Bean。</p>
 *
 * <p>数据类型自动识别：</p>
 * <ul>
 *   <li>{@code String} / {@code Number} — 普通变量 {@code ${key}}</li>
 *   <li>{@code Boolean} — 条件区块 {@code ${?key}...${/key}}</li>
 *   <li>{@code Map} — 映射区块</li>
 *   <li>{@code List} — 循环区块 / 列表展开 {@code ${%key}}</li>
 *   <li>{@link PictureData} — 图片 {@code ${@key}}（通过 {@code .create()} 构建，支持尺寸/缩放控制）</li>
 *   <li>{@code byte[]} — 图片 {@code ${@key}}（自动包装为 PictureData）</li>
 *   <li>{@code Image} / {@code BufferedImage} — 图片 {@code ${@key}}（自动转 PNG）</li>
 *   <li>{@code File} — 图片文件 {@code ${@key}}（自动读取）</li>
 * </ul>
 */
public class WordGenerator {

    /** 列表展开默认分隔符，null 表示使用内置「、」 */
    private final String separator;

    /** 处理管线 */
    private final DocumentPipeline pipeline;

    /**
     * 使用默认配置创建实例（分隔符为「、」，管线为默认五步管线）。
     */
    public WordGenerator() {
        this.separator = null;
        this.pipeline = DocumentPipeline.createDefault();
    }

    /**
     * 使用自定义分隔符创建实例。
     *
     * @param separator 列表展开默认分隔符，如 {@code ", "}、{@code "；"}；null 表示使用内置「、」
     */
    public WordGenerator(String separator) {
        this.separator = separator;
        this.pipeline = DocumentPipeline.createDefault();
    }

    /**
     * 使用自定义分隔符和处理管线创建实例。
     *
     * @param separator 列表展开默认分隔符；null 表示使用内置「、」
     * @param pipeline  处理管线
     */
    public WordGenerator(String separator, DocumentPipeline pipeline) {
        this.separator = separator;
        this.pipeline = pipeline != null ? pipeline : DocumentPipeline.createDefault();
    }

    // ==================== 实例 generate 方法 ====================

    /**
     * 从字节数组加载模板并生成文档。
     *
     * @param template 模板字节数组（.docx 格式）
     * @param data     填充数据（支持 String/Number/Boolean/Map/List/PictureData/byte[]）
     * @return 生成后的文档字节数组
     * @throws IllegalArgumentException 如果 template 为 null
     * @throws Exception                模板解析或处理过程中的错误
     */
    public byte[] generate(byte[] template, Map<String, Object> data) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板不能为 null");
        WordprocessingMLPackage pkg = TemplateLoader.load(template);
        return doGenerate(pkg, data);
    }

    /**
     * 从文件对象加载模板并生成文档。
     *
     * @param template 模板文件对象（.docx 格式）
     * @param data     填充数据
     * @return 生成后的文档字节数组
     * @throws IllegalArgumentException 如果 template 为 null 或文件不存在
     * @throws Exception                模板解析或处理过程中的错误
     */
    public byte[] generate(File template, Map<String, Object> data) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板文件不能为 null");
        WordprocessingMLPackage pkg = TemplateLoader.load(template);
        return doGenerate(pkg, data);
    }

    /**
     * 从文件路径加载模板并生成文档。
     *
     * @param templatePath 模板文件路径（.docx 格式）
     * @param data         填充数据
     * @return 生成后的文档字节数组
     * @throws IllegalArgumentException 如果 templatePath 为 null 或文件不存在
     * @throws Exception                模板解析或处理过程中的错误
     */
    public byte[] generate(String templatePath, Map<String, Object> data) throws Exception {
        if (templatePath == null) throw new IllegalArgumentException("模板路径不能为 null");
        return generate(new File(templatePath), data);
    }

    // ==================== 静态 generateWord 方法 ====================

    /**
     * 静态便捷方法：从字节数组加载模板并生成文档（使用默认配置）。
     *
     * @param template 模板字节数组（.docx 格式）
     * @param data     填充数据
     * @return 生成后的文档字节数组
     * @throws Exception 模板解析或处理过程中的错误
     */
    public static byte[] generateWord(byte[] template, Map<String, Object> data) throws Exception {
        return new WordGenerator().generate(template, data);
    }

    /**
     * 静态便捷方法：从文件对象加载模板并生成文档（使用默认配置）。
     *
     * @param template 模板文件对象（.docx 格式）
     * @param data     填充数据
     * @return 生成后的文档字节数组
     * @throws Exception 模板解析或处理过程中的错误
     */
    public static byte[] generateWord(File template, Map<String, Object> data) throws Exception {
        return new WordGenerator().generate(template, data);
    }

    /**
     * 静态便捷方法：从文件路径加载模板并生成文档（使用默认配置）。
     *
     * @param templatePath 模板文件路径（.docx 格式）
     * @param data         填充数据
     * @return 生成后的文档字节数组
     * @throws Exception 模板解析或处理过程中的错误
     */
    public static byte[] generateWord(String templatePath, Map<String, Object> data) throws Exception {
        return new WordGenerator().generate(templatePath, data);
    }

    // ==================== 清空占位符 ====================

    /**
     * 清空文档中所有残留的 {@code ${...}} 占位符。
     *
     * <p>适用于模板处理完成后、转 PDF 前，清除未匹配的占位符。</p>
     *
     * @param template 模板字节数组
     * @return 清除占位符后的文档字节数组
     * @throws IllegalArgumentException 如果 template 为 null
     * @throws Exception 模板解析或处理过程中的错误
     */
    public static byte[] clearPlaceholders(byte[] template) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板不能为 null");
        return PlaceholderCleaner.clear(template);
    }

    /**
     * 清空文档中所有残留的 {@code ${...}} 占位符。
     *
     * @param template 模板文件对象
     * @return 清除占位符后的文档字节数组
     * @throws IllegalArgumentException 如果 template 为 null
     * @throws Exception 模板解析或处理过程中的错误
     */
    public static byte[] clearPlaceholders(File template) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板文件不能为 null");
        return PlaceholderCleaner.clear(template);
    }

    /**
     * 清空文档中所有残留的 {@code ${...}} 占位符。
     *
     * @param templatePath 模板文件路径
     * @return 清除占位符后的文档字节数组
     * @throws IllegalArgumentException 如果 templatePath 为 null
     * @throws Exception 模板解析或处理过程中的错误
     */
    public static byte[] clearPlaceholders(String templatePath) throws Exception {
        if (templatePath == null) throw new IllegalArgumentException("模板路径不能为 null");
        return PlaceholderCleaner.clear(templatePath);
    }

    // ==================== 提取模板信息 ====================

    /**
     * 提取文档中的所有纯文本内容（含页眉、页脚、文本框）。
     *
     * @param template 模板字节数组
     * @return 文档纯文本
     * @throws IllegalArgumentException 如果 template 为 null
     * @throws Exception 模板解析错误
     */
    public static String extractText(byte[] template) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板不能为 null");
        return TemplateExtractor.extractText(template);
    }

    /**
     * 提取文档中的所有纯文本内容（含页眉、页脚、文本框）。
     *
     * @param template 模板文件对象
     * @return 文档纯文本
     * @throws IllegalArgumentException 如果 template 为 null
     * @throws Exception 模板解析错误
     */
    public static String extractText(File template) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板文件不能为 null");
        return TemplateExtractor.extractText(template);
    }

    /**
     * 提取文档中的所有纯文本内容（含页眉、页脚、文本框）。
     *
     * @param templatePath 模板文件路径
     * @return 文档纯文本
     * @throws IllegalArgumentException 如果 templatePath 为 null
     * @throws Exception 模板解析错误
     */
    public static String extractText(String templatePath) throws Exception {
        if (templatePath == null) throw new IllegalArgumentException("模板路径不能为 null");
        return TemplateExtractor.extractText(templatePath);
    }

    /**
     * 提取文档中所有 {@code ${...}} 占位符的变量名集合。
     *
     * @param template 模板字节数组
     * @return 变量名集合（去重）
     * @throws IllegalArgumentException 如果 template 为 null
     * @throws Exception 模板解析错误
     */
    public static Set<String> extractVariables(byte[] template) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板不能为 null");
        return TemplateExtractor.extractVariables(template);
    }

    /**
     * 提取文档中所有 {@code ${...}} 占位符的变量名集合。
     *
     * @param template 模板文件对象
     * @return 变量名集合（去重）
     * @throws IllegalArgumentException 如果 template 为 null
     * @throws Exception 模板解析错误
     */
    public static Set<String> extractVariables(File template) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板文件不能为 null");
        return TemplateExtractor.extractVariables(template);
    }

    /**
     * 提取文档中所有 {@code ${...}} 占位符的变量名集合。
     *
     * @param templatePath 模板文件路径
     * @return 变量名集合（去重）
     * @throws IllegalArgumentException 如果 templatePath 为 null
     * @throws Exception 模板解析错误
     */
    public static Set<String> extractVariables(String templatePath) throws Exception {
        if (templatePath == null) throw new IllegalArgumentException("模板路径不能为 null");
        return TemplateExtractor.extractVariables(templatePath);
    }

    // ==================== 内部方法 ====================

    private byte[] doGenerate(WordprocessingMLPackage pkg, Map<String, Object> data)
            throws Exception {
        ProcessingContext context = new ProcessingContext(data);
        context.setSeparator(separator);
        pipeline.execute(pkg, context);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        pkg.save(baos);
        return baos.toByteArray();
    }
}
