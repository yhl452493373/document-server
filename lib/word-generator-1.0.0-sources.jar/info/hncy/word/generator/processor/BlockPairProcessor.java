package info.hncy.word.generator.processor;

import info.hncy.word.generator.DocumentProcessor;
import info.hncy.word.generator.ProcessingContext;

import org.docx4j.XmlUtils;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.JaxbXmlPart;
import org.docx4j.wml.CTTxbxContent;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.P;
import org.docx4j.wml.R;
import org.docx4j.wml.RPr;
import org.docx4j.wml.Text;

import info.hncy.word.generator.model.PictureData;
import info.hncy.word.generator.support.ProcessorUtils;
import info.hncy.word.generator.support.TextBoxHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.Image;
import java.io.File;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 区块对（Block Pair）处理器 —— 实现类似 poi-tl 中 {@code ${?tag}...${/tag}}
 * 的条件区块语法，本项目标签以 {@code ${}} 包裹：
 *
 * <pre>
 *   ${?name} ... ${/name}
 * </pre>
 *
 * <p>支持三种数据驱动模式（与 poi-tl 区块对语义一致）：</p>
 * <ul>
 *   <li><b>条件区块</b>（值为 Boolean）：true 保留内容并剥掉标签；false/null 删除标签及全部内容。</li>
 *   <li><b>单次渲染</b>（值为 Map）：剥掉标签，用 Map 中的数据解析区块内的 {@code ${var}}。</li>
 *   <li><b>循环迭代</b>（值为 List&lt;Map&gt;）：空集隐藏；非空则将区块内容复制 N 份，
 *       每份用对应 item 的数据解析变量。自动注入 {@code _index}（0-based 循环索引）。</li>
 * </ul>
 *
 * <p>同段落区块和跨段落区块均支持。支持嵌套（按栈配对）；标签不配对时抛出异常。</p>
 *
 * <p><b>调用时机：</b>必须在 {@link RunMergeProcessor} 之后、
 * {@link VariableReplaceProcessor} 之前执行。</p>
 *
 * <p>处理范围：正文 + 所有页眉/页脚部件。</p>
 */
public class BlockPairProcessor implements DocumentProcessor {

    private static final Logger log = LoggerFactory.getLogger(BlockPairProcessor.class);

    /** 区块对标签模式（实例字段，由构造函数注入） */
    private final Pattern tagPattern;

    /** 普通变量模式（实例字段，由构造函数注入） */
    private final Pattern varPattern;

    /** 循环迭代中注入的索引变量名 */
    private final String indexVarName;

    /** 数据表：key 为标签名，value 为 Boolean / Map / List，从 context 获取 */
    private Map<String, Object> data;

    /** 原始未展平数据：保留嵌套结构，用于查找 Map/List 类型的区块值 */
    private Map<String, Object> originalData;

    /** 图片池引用（从 context 获取，用于写入循环中生成的图片条目） */
    private Map<String, PictureData> images;

    private int imgCounter;
    private int keptBlocks;
    private int removedBlocks;
    private int expandedBlocks;

    /**
     * 使用默认占位符语法（${...}）和默认索引变量名（_index）。
     */
    public BlockPairProcessor() {
        this(
                Pattern.compile("\\$\\{([?/])([^}]*)\\}"),
                Pattern.compile("\\$\\{([^@?/%][^}]*)\\}"),
                "_index");
    }

    /**
     * @param tagPattern   区块对标签正则（需含两个 group：group(1) 为 ? 或 /，group(2) 为名称）
     * @param varPattern   普通变量正则（group(1) 为变量名）
     * @param indexVarName 循环迭代中注入的索引变量名
     */
    public BlockPairProcessor(Pattern tagPattern, Pattern varPattern, String indexVarName) {
        this.tagPattern = tagPattern;
        this.varPattern = varPattern;
        this.indexVarName = indexVarName != null ? indexVarName : "_index";
    }

    /** 处理结果统计 */
    public static class Result {
        public final int keptBlocks;
        public final int removedBlocks;
        public final int expandedBlocks;

        Result(int keptBlocks, int removedBlocks, int expandedBlocks) {
            this.keptBlocks = keptBlocks;
            this.removedBlocks = removedBlocks;
            this.expandedBlocks = expandedBlocks;
        }

        @Override
        public String toString() {
            return "区块对处理结果：保留 " + keptBlocks + " 个，移除 " + removedBlocks
                    + " 个，展开 " + expandedBlocks + " 个";
        }
    }

    /**
     * 执行区块对处理。
     *
     * <p>从上下文中获取数据和图片池，然后遍历文档（正文 + 页眉/页脚 + 文本框），
     * 处理所有 {@code ${?name}...${/name}} 区块对。</p>
     *
     * @param pkg     文档包
     * @param context 处理上下文（包含数据和图片池）
     */
    @Override
    public void process(WordprocessingMLPackage pkg, ProcessingContext context) {
        this.data = context.getOthers();
        this.originalData = context.getOriginalData();
        this.images = context.getImages();
        process(pkg);
    }

    /**
     * 处理整个文档包（正文 + 页眉/页脚）中的所有区块对。
     *
     * @return 处理结果统计
     * @throws IllegalStateException 区块对标签不配对时
     */
    public Result process(WordprocessingMLPackage pkg) {
        if (data == null) {
            throw new IllegalStateException("请先调用 process(pkg, context) 设置数据");
        }
        keptBlocks = 0;
        removedBlocks = 0;
        expandedBlocks = 0;
        imgCounter = 0;
        for (JaxbXmlPart<?> part : ProcessorUtils.collectParts(pkg)) {
            processPart(part);
        }
        return new Result(keptBlocks, removedBlocks, expandedBlocks);
    }

    // ------------------------------------------------------------------
    // 配对 + 应用
    // ------------------------------------------------------------------

    private void processPart(JaxbXmlPart<?> part) {
        List<ParaCtx> paragraphs = collectParagraphs(part);

        // ---------- 第一遍：配对 ----------
        List<Block> blocks = new ArrayList<Block>();
        Deque<OpenBlock> stack = new ArrayDeque<OpenBlock>();

        for (ParaCtx ctx : paragraphs) {
            String text = concatText(buildSegs(ctx.paragraph));
            Matcher m = tagPattern.matcher(text);
            Map<String, Integer> ordinalInPara = new HashMap<String, Integer>();
            while (m.find()) {
                boolean isStart = "?".equals(m.group(1));
                String name = m.group(2);
                String literal = m.group();
                int ordinal = nextOrdinal(ordinalInPara, literal);
                TagRef ref = new TagRef(ctx, literal, ordinal);

                if (isStart) {
                    stack.push(new OpenBlock(name, ref));
                } else {
                    OpenBlock open = stack.peek();
                    if (open == null || !open.name.equals(name)) {
                        throw new IllegalStateException(
                                "区块对标签不配对：遇到结束标签 " + literal
                                        + "，但当前未关闭的开始标签为 "
                                        + (open == null ? "（无）" : "${?" + open.name + "}")
                                        + "，所在段落文本：" + text);
                    }
                    stack.pop();
                    blocks.add(new Block(open.name, open.start, ref));
                }
            }
        }
        if (!stack.isEmpty()) {
            OpenBlock unclosed = stack.pop();
            throw new IllegalStateException(
                    "区块对未闭合：开始标签 ${?" + unclosed.name + "} 缺少匹配的 ${/"
                            + unclosed.name + "}");
        }

        // ---------- 第二遍：逆序应用 ----------
        for (int i = blocks.size() - 1; i >= 0; i--) {
            applyBlock(blocks.get(i), paragraphs);
        }
    }

    /**
     * 按路径从 data 中取值。支持点号嵌套路径（poi-tl 风格），
     * 如 {@code "group.items"} 等价于 {@code data.get("group").get("items")}。
     * 优先按完整 key 直接查找（兼容 key 本身含点号的情况），找不到再按路径逐层解析。
     */
    @SuppressWarnings("unchecked")
    private Object resolvePath(String path) {
        if (data.containsKey(path)) {
            return data.get(path);
        }
        if (images != null && images.containsKey(path)) {
            return images.get(path);
        }
        if (originalData != null) {
            return resolveFromOriginal(path);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private Object resolveFromOriginal(String path) {
        if (originalData.containsKey(path)) {
            return originalData.get(path);
        }
        if (!path.contains(".")) {
            return null;
        }
        String[] parts = path.split("\\.");
        Object current = originalData;
        for (String part : parts) {
            if (current instanceof Map) {
                current = ((Map<String, Object>) current).get(part);
            } else {
                return null;
            }
        }
        return current;
    }

    /** 应用一个已配对的区块，根据 data 中的值类型决定处理方式 */
    private void applyBlock(Block block, List<ParaCtx> paragraphs) {
        // 嵌套保护
        if (block.start.ctx.removed || block.end.ctx.removed) {
            return;
        }
        if (concatText(buildSegs(block.start.ctx.paragraph)).indexOf(block.start.literal) < 0
                || concatText(buildSegs(block.end.ctx.paragraph)).indexOf(block.end.literal) < 0) {
            return;
        }

        // 跨容器检测：标签在不同 parentContent 中（如不同表格单元格）时跳过
        if (block.start.ctx.parentContent != block.end.ctx.parentContent) {
            log.warn("区块 ${?" + block.name + "} 的开始和结束标签位于不同容器中，跳过处理（跨单元格渲染行为未定义）");
            return;
        }

        Object value = resolvePath(block.name);

        if (value instanceof List) {
            List<?> list = (List<?>) value;
            if (list.isEmpty()) {
                removeBlock(block, paragraphs);
                removedBlocks++;
            } else {
                expandCollectionBlock(block, paragraphs, list);
                expandedBlocks++;
            }
            return;
        }

        if (value instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, ?> mapData = (Map<String, ?>) value;
            Map<String, String> stringMap = new LinkedHashMap<String, String>();
            Map<String, String> imgKeyMapping = new LinkedHashMap<String, String>();
            for (Map.Entry<String, ?> e : mapData.entrySet()) {
                if (e.getKey() == null) continue;
                String key = e.getKey();
                classifyListItemValue(e.getValue(), key, stringMap, imgKeyMapping);
            }
            keptBlocks++;
            stripTagsAndResolve(block, paragraphs, stringMap);

            if (!imgKeyMapping.isEmpty()) {
                rewriteImagePlaceholders(block, imgKeyMapping);
            }
            return;
        }

        // Boolean / null / 图片类型 → 条件区块
        boolean keep;
        if (value instanceof Boolean) {
            keep = Boolean.TRUE.equals(value);
        } else {
            keep = value != null;
        }
        if (keep) {
            keptBlocks++;
            stripTag(block.end);
            stripTag(block.start);
            removeParagraphIfEmptyAndSafe(block.end.ctx);
            if (block.start.ctx != block.end.ctx) {
                removeParagraphIfEmptyAndSafe(block.start.ctx);
            }
        } else {
            removeBlock(block, paragraphs);
            removedBlocks++;
        }
    }

    /** 条件 false / 空集：删除标签及中间全部内容 */
    private void removeBlock(Block block, List<ParaCtx> paragraphs) {
        ParaCtx startCtx = block.start.ctx;
        ParaCtx endCtx = block.end.ctx;

        if (startCtx == endCtx) {
            int s = locate(startCtx, block.start.literal, block.start.ordinal)[0];
            int e = locate(endCtx, block.end.literal, block.end.ordinal)[1];
            deleteRange(startCtx.paragraph, s, e);
            removeParagraphIfEmptyAndSafe(startCtx);
            return;
        }

        List<Object> parent = startCtx.parentContent;

        // 删除 start 和 end 之间的所有元素（包括表格等），逆序删除保持索引稳定
        for (int idx = endCtx.parentIndex - 1; idx > startCtx.parentIndex; idx--) {
            parent.remove(idx);
        }

        // 裁剪结束段落：删除标签及之前内容
        int eEnd = locate(endCtx, block.end.literal, block.end.ordinal)[1];
        deleteRange(endCtx.paragraph, 0, eEnd);
        removeParagraphIfEmptyAndSafe(endCtx);

        // 裁剪开始段落：删除标签及之后内容
        int sStart = locate(startCtx, block.start.literal, block.start.ordinal)[0];
        deleteRange(startCtx.paragraph, sStart, Integer.MAX_VALUE);
        removeParagraphIfEmptyAndSafe(startCtx);
    }

    // ------------------------------------------------------------------
    // 循环迭代：跨段落
    // ------------------------------------------------------------------

    /** 跨段落循环：深拷贝模板元素 → 解析变量 → 插入副本 → 删除原始 */
    @SuppressWarnings("unchecked")
    private void expandCollectionBlock(Block block, List<ParaCtx> paragraphs, List<?> list) {
        if (block.start.ctx == block.end.ctx) {
            expandSameParagraphCollection(block, list);
            return;
        }

        ParaCtx startCtx = block.start.ctx;
        ParaCtx endCtx = block.end.ctx;
        List<Object> startParent = startCtx.parentContent;

        // 定位标签位置
        int[] sPos = locate(startCtx, block.start.literal, block.start.ordinal);
        int[] ePos = locate(endCtx, block.end.literal, block.end.ordinal);

        // 收集模板元素（start 到 end 之间的所有 body 级元素，包括表格等）
        List<Object> templateElements = new ArrayList<Object>();
        for (int idx = startCtx.parentIndex; idx <= endCtx.parentIndex; idx++) {
            templateElements.add(startParent.get(idx));
        }

        // 为每个 item 创建副本、解析变量、插入文档
        int insertAfterIdx = startCtx.parentIndex;

        for (int i = 0; i < list.size(); i++) {
            Map<String, String> itemTextData = new LinkedHashMap<String, String>();
            Map<String, String> imgKeyMapping = new LinkedHashMap<String, String>();
            itemTextData.put(indexVarName, String.valueOf(i));
            Object item = list.get(i);
            if (item instanceof Map) {
                for (Map.Entry<?, ?> e : ((Map<?, ?>) item).entrySet()) {
                    if (e.getKey() == null) continue;
                    String key = String.valueOf(e.getKey());
                    classifyListItemValue(e.getValue(), key, itemTextData, imgKeyMapping);
                }
            }

            // 深拷贝所有模板元素
            List<Object> copies = new ArrayList<Object>();
            for (Object template : templateElements) {
                copies.add(XmlUtils.deepCopy(template));
            }

            // 裁剪开始段落副本：保留标签之前的内容，删除标签及之后内容
            Object firstUnwrapped = XmlUtils.unwrap(copies.get(0));
            if (firstUnwrapped instanceof P) {
                deleteRange((P) firstUnwrapped, sPos[0], Integer.MAX_VALUE);
            }

            // 裁剪结束段落副本：删除标签及之前的内容，保留标签之后的内容
            Object lastUnwrapped = XmlUtils.unwrap(copies.get(copies.size() - 1));
            if (lastUnwrapped instanceof P) {
                deleteRange((P) lastUnwrapped, 0, ePos[1]);
            }

            // 递归解析变量（包括表格内的段落）
            for (Object copy : copies) {
                resolveVariablesInElement(copy, itemTextData);
            }

            // 将 ${@originalKey} 替换为 ${@_bi_N}（varPattern 不匹配 @ 前缀，需单独处理）
            if (!imgKeyMapping.isEmpty()) {
                for (Object copy : copies) {
                    replaceImagePlaceholders(copy, imgKeyMapping);
                }
            }

            // 过滤空段落，保留非段落元素（如表格）
            List<Object> filteredCopies = new ArrayList<Object>();
            for (Object copy : copies) {
                Object unwrapped = XmlUtils.unwrap(copy);
                if (unwrapped instanceof P) {
                    String text = concatText(buildSegs((P) unwrapped));
                    if (!text.trim().isEmpty()) {
                        filteredCopies.add(copy);
                    }
                } else {
                    filteredCopies.add(copy);
                }
            }

            // 插入副本到开始位置之后
            for (int j = filteredCopies.size() - 1; j >= 0; j--) {
                startParent.add(insertAfterIdx + 1, filteredCopies.get(j));
            }
            insertAfterIdx += filteredCopies.size();
        }

        // 删除原始模板元素（按 identity 查找，因为插入副本后索引已偏移）
        for (Object template : templateElements) {
            removeFromParent(startParent, XmlUtils.unwrap(template));
        }
    }

    // ------------------------------------------------------------------
    // 循环迭代：同段落
    // ------------------------------------------------------------------

    /** 同段落循环：提取模板文本 → 展开 N 份 → 重建段落 */
    @SuppressWarnings("unchecked")
    private void expandSameParagraphCollection(Block block, List<?> list) {
        ParaCtx ctx = block.start.ctx;
        P p = ctx.paragraph;
        String text = concatText(buildSegs(p));

        int[] startTagResult = locate(ctx, block.start.literal, block.start.ordinal);
        int[] endTagResult = locate(ctx, block.end.literal, block.end.ordinal);
        int startTagPos = startTagResult[0];
        int endTagPos = endTagResult[0];

        String prefix = text.substring(0, startTagPos);
        String template = text.substring(startTagPos + block.start.literal.length(), endTagPos);
        String suffix = text.substring(endTagResult[1]);

        StringBuilder expanded = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            Map<String, String> itemData = new LinkedHashMap<String, String>();
            Map<String, String> imgKeyMapping = new LinkedHashMap<String, String>();
            itemData.put(indexVarName, String.valueOf(i));
            Object item = list.get(i);
            if (item instanceof Map) {
                for (Map.Entry<?, ?> e : ((Map<?, ?>) item).entrySet()) {
                    if (e.getKey() == null) continue;
                    String key = String.valueOf(e.getKey());
                    classifyListItemValue(e.getValue(), key, itemData, imgKeyMapping);
                }
            }
            String resolved = resolveVariablesInText(template, itemData);
            if (!imgKeyMapping.isEmpty()) {
                StringBuilder alternation = new StringBuilder();
                List<String> keys = new ArrayList<String>(imgKeyMapping.keySet());
                java.util.Collections.sort(keys, new java.util.Comparator<String>() {
                    @Override public int compare(String a, String b) { return b.length() - a.length(); }
                });
                for (int k = 0; k < keys.size(); k++) {
                    if (k > 0) alternation.append('|');
                    alternation.append("\\$\\{@").append(Pattern.quote(keys.get(k))).append("\\}");
                }
                Matcher imgMatcher = Pattern.compile(alternation.toString()).matcher(resolved);
                StringBuffer imgSb = new StringBuffer();
                while (imgMatcher.find()) {
                    String matched = imgMatcher.group();
                    String origKey = matched.substring(3, matched.length() - 1);
                    imgMatcher.appendReplacement(imgSb, Matcher.quoteReplacement("${@" + imgKeyMapping.get(origKey) + "}"));
                }
                imgMatcher.appendTail(imgSb);
                resolved = imgSb.toString();
            }
            expanded.append(resolved);
        }

        String finalText = prefix + expanded.toString() + suffix;
        rebuildParagraph(p, finalText);
    }

    // ------------------------------------------------------------------
    // Map 单次渲染：剥标签 + 解析变量
    // ------------------------------------------------------------------

    /** 剥掉标签，然后用 mapData 解析区块内的变量 */
    private void stripTagsAndResolve(Block block, List<ParaCtx> paragraphs, Map<String, String> mapData) {
        if (block.start.ctx == block.end.ctx) {
            resolveVariablesInParagraph(block.start.ctx.paragraph, mapData);
            stripTag(block.end);
            stripTag(block.start);
            removeParagraphIfEmptyAndSafe(block.end.ctx);
            return;
        }

        ParaCtx startCtx = block.start.ctx;
        ParaCtx endCtx = block.end.ctx;
        List<Object> parent = startCtx.parentContent;

        for (int idx = startCtx.parentIndex; idx <= endCtx.parentIndex; idx++) {
            resolveVariablesInElement(parent.get(idx), mapData);
        }
        stripTag(block.end);
        stripTag(block.start);
        removeParagraphIfEmptyAndSafe(block.end.ctx);
        if (block.start.ctx != block.end.ctx) {
            removeParagraphIfEmptyAndSafe(block.start.ctx);
        }
    }

    /** 将区块内的 ${@key} 占位符重写为内部图片键 ${@_bi_N} */
    private void rewriteImagePlaceholders(Block block, Map<String, String> imgKeyMapping) {
        List<String> keys = new ArrayList<String>(imgKeyMapping.keySet());
        java.util.Collections.sort(keys, new java.util.Comparator<String>() {
            @Override public int compare(String a, String b) { return b.length() - a.length(); }
        });

        StringBuilder alternation = new StringBuilder();
        for (int k = 0; k < keys.size(); k++) {
            if (k > 0) alternation.append('|');
            alternation.append("\\$\\{@").append(Pattern.quote(keys.get(k))).append("\\}");
        }
        Pattern pattern = Pattern.compile(alternation.toString());

        ParaCtx startCtx = block.start.ctx;
        ParaCtx endCtx = block.end.ctx;
        List<Object> parent = startCtx.parentContent;

        for (int idx = startCtx.parentIndex; idx <= endCtx.parentIndex; idx++) {
            rewriteImagePlaceholdersInNode(parent.get(idx), pattern, imgKeyMapping);
        }
    }

    private void rewriteImagePlaceholdersInNode(Object node, Pattern pattern, Map<String, String> imgKeyMapping) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof R) {
            R run = (R) o;
            for (Object item : run.getContent()) {
                Object val = XmlUtils.unwrap(item);
                if (val instanceof Text) {
                    Text text = (Text) val;
                    String value = text.getValue();
                    if (value != null && value.contains("${@")) {
                        Matcher m = pattern.matcher(value);
                        StringBuffer sb = new StringBuffer();
                        while (m.find()) {
                            String matched = m.group();
                            String origKey = matched.substring(3, matched.length() - 1);
                            m.appendReplacement(sb, Matcher.quoteReplacement("${@" + imgKeyMapping.get(origKey) + "}"));
                        }
                        m.appendTail(sb);
                        text.setValue(sb.toString());
                    }
                }
            }
            return;
        }
        if (o instanceof ContentAccessor) {
            for (Object child : ((ContentAccessor) o).getContent()) {
                rewriteImagePlaceholdersInNode(child, pattern, imgKeyMapping);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            rewriteImagePlaceholdersInNode(txbx, pattern, imgKeyMapping);
        }
    }

    // ------------------------------------------------------------------
    // 变量解析
    // ------------------------------------------------------------------

    /** 解析段落中所有 Text 节点的 ${var} 变量（含文本框） */
    private void resolveVariablesInParagraph(P p, Map<String, String> resolvedData) {
        List<Seg> segs = buildSegs(p);
        for (Seg seg : segs) {
            if (seg.isText && seg.text.getValue() != null) {
                String resolved = resolveVariablesInText(seg.text.getValue(), resolvedData);
                seg.text.setValue(resolved);
            }
        }
        for (Object run : p.getContent()) {
            Object o = XmlUtils.unwrap(run);
            if (o instanceof R) {
                for (Object item : ((R) o).getContent()) {
                    for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(item)) {
                        resolveVariablesInElement(txbx, resolvedData);
                    }
                }
            }
        }
    }

    /** 递归解析元素中所有层级的变量（进入 Tbl → Tr → Tc → P + 文本框） */
    private void resolveVariablesInElement(Object element, Map<String, String> data) {
        Object o = XmlUtils.unwrap(element);
        if (o instanceof P) {
            resolveVariablesInParagraph((P) o, data);
        } else if (o instanceof ContentAccessor) {
            for (Object child : ((ContentAccessor) o).getContent()) {
                resolveVariablesInElement(child, data);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            resolveVariablesInElement(txbx, data);
        }
    }

    /**
     * 递归遍历元素树，将 Text 节点中的 {@code ${@originalKey}} 替换为 {@code ${@_bi_N}}。
     * varPattern 不匹配 @ 前缀占位符，因此图片占位符需要单独替换。
     * 使用单次正则替换（按键长降序排列）避免子串碰撞。
     * 同时进入文本框（TextBox）内部遍历。
     */
    private void replaceImagePlaceholders(Object element, Map<String, String> imgKeyMapping) {
        Object o = XmlUtils.unwrap(element);
        if (o instanceof P) {
            List<Seg> segs = buildSegs((P) o);
            for (Seg seg : segs) {
                if (seg.isText && seg.text.getValue() != null) {
                    seg.text.setValue(replaceImageKeysInText(seg.text.getValue(), imgKeyMapping));
                }
            }
        } else if (o instanceof ContentAccessor) {
            for (Object child : ((ContentAccessor) o).getContent()) {
                replaceImagePlaceholders(child, imgKeyMapping);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            replaceImagePlaceholders(txbx, imgKeyMapping);
        }
    }

    /** 使用单次正则替换将文本中的 ${@key} 替换为 ${@_bi_N}，按键长降序避免子串碰撞 */
    private static String replaceImageKeysInText(String text, Map<String, String> imgKeyMapping) {
        List<String> keys = new ArrayList<String>(imgKeyMapping.keySet());
        java.util.Collections.sort(keys, new java.util.Comparator<String>() {
            @Override public int compare(String a, String b) { return b.length() - a.length(); }
        });
        StringBuilder alternation = new StringBuilder();
        for (int k = 0; k < keys.size(); k++) {
            if (k > 0) alternation.append('|');
            alternation.append("\\$\\{@").append(Pattern.quote(keys.get(k))).append("\\}");
        }
        Matcher m = Pattern.compile(alternation.toString()).matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String matched = m.group();
            String origKey = matched.substring(3, matched.length() - 1);
            m.appendReplacement(sb, Matcher.quoteReplacement("${@" + imgKeyMapping.get(origKey) + "}"));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** 解析文本中的 ${var} 变量，返回替换后的文本 */
    private String resolveVariablesInText(String text, Map<String, String> resolvedData) {
        Matcher m = varPattern.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String key = m.group(1);
            String value = resolvedData.get(key);
            if (value != null) {
                m.appendReplacement(sb, Matcher.quoteReplacement(value));
            }
        }
        m.appendTail(sb);
        return sb.toString();
    }

    // ------------------------------------------------------------------
    // 段落重建（用于同段落循环展开）
    // ------------------------------------------------------------------

    /** 用给定文本重建段落：清除所有 run，创建一个包含最终文本的新 run，保留非文本元素 */
    private void rebuildParagraph(P p, String text) {
        RPr rpr = getFirstRPr(p);

        List<Object> nonTextElements = new ArrayList<Object>();
        for (Object item : p.getContent()) {
            Object val = XmlUtils.unwrap(item);
            if (val instanceof R) {
                R run = (R) val;
                for (Object runItem : run.getContent()) {
                    Object unwrapped = XmlUtils.unwrap(runItem);
                    if (!(unwrapped instanceof Text) && !(unwrapped instanceof org.docx4j.wml.Br)) {
                        nonTextElements.add(runItem);
                    }
                }
            } else if (!(val instanceof org.docx4j.wml.Br)) {
                nonTextElements.add(item);
            }
        }

        p.getContent().clear();

        if (!text.isEmpty()) {
            R r = new R();
            if (rpr != null) {
                r.setRPr(rpr);
            }
            Text t = new Text();
            t.setValue(text);
            t.setSpace("preserve");
            r.getContent().add(t);
            p.getContent().add(r);
        }

        for (Object elem : nonTextElements) {
            p.getContent().add(elem);
        }
    }

    /** 获取段落中第一个非空 run 的 RPr（格式信息），用于重建时保持格式 */
    private RPr getFirstRPr(P p) {
        for (Object item : p.getContent()) {
            Object val = XmlUtils.unwrap(item);
            if (val instanceof R) {
                RPr rpr = ((R) val).getRPr();
                if (rpr != null) {
                    return XmlUtils.deepCopy(rpr);
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // 标签定位辅助（用于跨段落循环的标签删除）
    // ------------------------------------------------------------------

    /** 在父内容列表中查找对象的索引 */
    private static int indexOf(List<Object> list, Object target) {
        for (int i = 0; i < list.size(); i++) {
            if (XmlUtils.unwrap(list.get(i)) == target) {
                return i;
            }
        }
        return -1;
    }

    // ------------------------------------------------------------------
    // 以下为此前已存在的段落/文本编辑基础设施
    // ------------------------------------------------------------------

    private void stripTag(TagRef ref) {
        int[] pos = locate(ref.ctx, ref.literal, ref.ordinal);
        deleteRange(ref.ctx.paragraph, pos[0], pos[1]);
    }

    private int[] locate(ParaCtx ctx, String literal, int ordinal) {
        String text = concatText(buildSegs(ctx.paragraph));
        int from = 0;
        for (int n = 0; n < ordinal; n++) {
            int idx = text.indexOf(literal, from);
            if (idx < 0) {
                throw new IllegalStateException(
                        "区块标签 " + literal + "（第 " + ordinal + " 次出现）在段落中找不到，"
                                + "当前段落文本：" + text);
            }
            if (n == ordinal - 1) {
                return new int[]{idx, idx + literal.length()};
            }
            from = idx + literal.length();
        }
        throw new IllegalStateException("unreachable");
    }

    // ------------------------------------------------------------------
    // 段落 / 文本片段（seg）结构与编辑
    // ------------------------------------------------------------------

    private static class ParaCtx {
        final P paragraph;
        final List<Object> parentContent;
        final int index;
        final int parentIndex;
        boolean removed;

        ParaCtx(P paragraph, List<Object> parentContent, int index, int parentIndex) {
            this.paragraph = paragraph;
            this.parentContent = parentContent;
            this.index = index;
            this.parentIndex = parentIndex;
        }
    }

    private static class Seg {
        boolean isText;
        Text text;
        Object mark;
        R run;
        List<Object> runParent;
    }

    private static List<ParaCtx> collectParagraphs(JaxbXmlPart<?> part) {
        List<ParaCtx> out = new ArrayList<ParaCtx>();
        walkParagraphs(part.getJaxbElement(), null, out, new int[]{0});
        return out;
    }

    private static void walkParagraphs(Object node, List<Object> parentContent,
                                       List<ParaCtx> out, int[] index) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof P) {
            int pIdx = parentContent != null ? indexOf(parentContent, o) : -1;
            out.add(new ParaCtx((P) o, parentContent, index[0]++, pIdx));
        }
        if (o instanceof ContentAccessor) {
            List<Object> content = ((ContentAccessor) o).getContent();
            for (Object child : new ArrayList<Object>(content)) {
                walkParagraphs(child, content, out, index);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            walkParagraphs(txbx, txbx.getContent(), out, index);
        }
    }

    private static List<Seg> buildSegs(P paragraph) {
        List<Seg> segs = new ArrayList<Seg>();
        collectSegs(paragraph, segs);
        return segs;
    }

    private static void collectSegs(Object node, List<Seg> segs) {
        collectSegs(node, null, segs);
    }

    private static void collectSegs(Object node, List<Object> runParent, List<Seg> segs) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof R) {
            R r = (R) o;
            for (Object item : r.getContent()) {
                Object val = XmlUtils.unwrap(item);
                Seg seg = new Seg();
                seg.run = r;
                seg.runParent = runParent;
                if (val instanceof Text) {
                    seg.isText = true;
                    seg.text = (Text) val;
                } else {
                    seg.isText = false;
                    seg.mark = item;
                }
                segs.add(seg);
            }
            return;
        }
        if (o instanceof ContentAccessor) {
            List<Object> content = ((ContentAccessor) o).getContent();
            for (Object child : new ArrayList<Object>(content)) {
                collectSegs(child, content, segs);
            }
        }
    }

    private static String concatText(List<Seg> segs) {
        StringBuilder sb = new StringBuilder();
        for (Seg seg : segs) {
            if (seg.isText && seg.text.getValue() != null) {
                sb.append(seg.text.getValue());
            }
        }
        return sb.toString();
    }

    private static void deleteRange(P paragraph, int from, int to) {
        List<Seg> segs = buildSegs(paragraph);
        int pos = 0;
        Map<R, List<Object>> touchedRuns = new LinkedHashMap<R, List<Object>>();

        for (Seg seg : segs) {
            if (seg.isText) {
                String value = seg.text.getValue() != null ? seg.text.getValue() : "";
                int segStart = pos;
                int segEnd = pos + value.length();
                if (segEnd > from && segStart < to) {
                    String prefix = value.substring(0, Math.max(0, from - segStart));
                    String suffix = value.substring(Math.min(value.length(), to - segStart));
                    seg.text.setValue(prefix + suffix);
                    touchedRuns.put(seg.run, seg.runParent);
                }
                pos = segEnd;
            } else {
                if (pos >= from && pos < to) {
                    seg.run.getContent().remove(seg.mark);
                    touchedRuns.put(seg.run, seg.runParent);
                }
            }
        }

        for (Map.Entry<R, List<Object>> entry : touchedRuns.entrySet()) {
            if (!ProcessorUtils.runHasVisibleContent(entry.getKey())) {
                removeFromParent(entry.getValue(), entry.getKey());
            }
        }
    }

    private void removeParagraphIfEmptyAndSafe(ParaCtx ctx) {
        String text = concatText(buildSegs(ctx.paragraph));
        if (text.trim().isEmpty()) {
            removeParagraphIfSafe(ctx);
        }
    }

    private void removeParagraphIfSafe(ParaCtx ctx) {
        List<Object> parent = ctx.parentContent;
        if (parent == null) {
            return;
        }
        int pCount = 0;
        for (Object item : parent) {
            if (XmlUtils.unwrap(item) instanceof P) {
                pCount++;
            }
        }
        if (pCount <= 1) {
            return;
        }
        removeFromParent(ctx.parentContent, ctx.paragraph);
        ctx.removed = true;
    }

    private static void removeFromParent(List<Object> parentList, Object target) {
        if (parentList == null) {
            return;
        }
        for (Iterator<Object> it = parentList.iterator(); it.hasNext(); ) {
            if (XmlUtils.unwrap(it.next()) == target) {
                it.remove();
                return;
            }
        }
    }

    // ------------------------------------------------------------------
    // 部件收集与小工具
    // ------------------------------------------------------------------

    private static int nextOrdinal(Map<String, Integer> ordinalInPara, String literal) {
        Integer n = ordinalInPara.get(literal);
        int next = (n == null ? 0 : n) + 1;
        ordinalInPara.put(literal, next);
        return next;
    }

    /** 将列表项的值分类为图片或文本，分别写入对应映射 */
    private void classifyListItemValue(Object val, String key,
                                       Map<String, String> textData,
                                       Map<String, String> imgKeyMapping) {
        if (val instanceof PictureData) {
            String imgKey = "_bi_" + (++imgCounter);
            images.put(imgKey, (PictureData) val);
            imgKeyMapping.put(key, imgKey);
        } else if (val instanceof byte[]) {
            byte[] bytes = (byte[]) val;
            String imgKey = "_bi_" + (++imgCounter);
            images.put(imgKey, bytes.length > 0 ? PictureData.of(bytes) : PictureData.empty());
            imgKeyMapping.put(key, imgKey);
        } else if (val instanceof Image) {
            try {
                String imgKey = "_bi_" + (++imgCounter);
                images.put(imgKey, PictureData.of((Image) val));
                imgKeyMapping.put(key, imgKey);
            } catch (Exception ex) {
                log.warn("列表项图片 [{}] 解析失败: {}", key, ex.getMessage());
            }
        } else if (val instanceof File) {
            try {
                String imgKey = "_bi_" + (++imgCounter);
                images.put(imgKey, PictureData.of((File) val));
                imgKeyMapping.put(key, imgKey);
            } catch (Exception ex) {
                log.warn("列表项图片 [{}] 解析失败: {}", key, ex.getMessage());
            }
        } else {
            textData.put(key, val == null ? "" : String.valueOf(val));
        }
    }

    // ------------------------------------------------------------------
    // 配对过程中的内部结构
    // ------------------------------------------------------------------

    private static class TagRef {
        final ParaCtx ctx;
        final String literal;
        final int ordinal;

        TagRef(ParaCtx ctx, String literal, int ordinal) {
            this.ctx = ctx;
            this.literal = literal;
            this.ordinal = ordinal;
        }
    }

    private static class OpenBlock {
        final String name;
        final TagRef start;

        OpenBlock(String name, TagRef start) {
            this.name = name;
            this.start = start;
        }
    }

    private static class Block {
        final String name;
        final TagRef start;
        final TagRef end;

        Block(String name, TagRef start, TagRef end) {
            this.name = name;
            this.start = start;
            this.end = end;
        }
    }
}
