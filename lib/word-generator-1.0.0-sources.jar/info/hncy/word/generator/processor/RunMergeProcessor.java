package info.hncy.word.generator.processor;

import info.hncy.word.generator.DocumentProcessor;
import info.hncy.word.generator.ProcessingContext;

import info.hncy.word.generator.support.ProcessorUtils;
import info.hncy.word.generator.support.TextBoxHelper;

import org.docx4j.model.datastorage.migration.VariablePrepare;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.JaxbXmlPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FooterPart;
import org.docx4j.openpackaging.parts.WordprocessingML.HeaderPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FootnotesPart;
import org.docx4j.openpackaging.parts.WordprocessingML.EndnotesPart;
import org.docx4j.utils.SingleTraversalUtilVisitorCallback;

/**
 * Run 合并准备处理器 —— 合并被 Word 拆散的 run，使后续处理器能正确匹配标签文本。
 *
 * <p>包含三个步骤：</p>
 * <ol>
 *   <li>调用 docx4j 的 {@link VariablePrepare#prepare} 合并正文 run</li>
 *   <li>对页眉/页脚部件执行同样的 run 合并</li>
 *   <li>合并文本框内的 run</li>
 * </ol>
 */
public class RunMergeProcessor implements DocumentProcessor {

    /**
     * 执行 run 合并预处理。
     *
     * <p>依次完成以下步骤：</p>
     * <ol>
     *   <li>调用 docx4j 的 {@link VariablePrepare#prepare} 合并正文中的 run</li>
     *   <li>对页眉/页脚部件执行同样的 run 合并</li>
     *   <li>合并文本框内的 run（通过 {@link TextBoxHelper#mergeRunsInTextBoxes}）</li>
     * </ol>
     *
     * @param pkg     文档包
     * @param context 处理上下文（本处理器不使用）
     * @throws Exception 处理过程中的错误
     */
    @Override
    public void process(WordprocessingMLPackage pkg, ProcessingContext context) throws Exception {
        VariablePrepare.prepare(pkg);

        SingleTraversalUtilVisitorCallback runJoiner =
                new SingleTraversalUtilVisitorCallback(
                        new VariablePrepare.TraversalUtilParagraphVisitor());

        for (JaxbXmlPart<?> part : ProcessorUtils.collectParts(pkg)) {
            if (part instanceof HeaderPart || part instanceof FooterPart
                    || part instanceof FootnotesPart || part instanceof EndnotesPart) {
                runJoiner.walkJAXBElements(part.getJaxbElement());
            }
            TextBoxHelper.mergeRunsInTextBoxes(part.getJaxbElement());
        }
    }
}
