package info.hncy.word.generator.processor;

import info.hncy.word.generator.DocumentProcessor;
import info.hncy.word.generator.ProcessingContext;

import org.docx4j.XmlUtils;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.JaxbXmlPart;
import org.docx4j.wml.CTTxbxContent;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.ObjectFactory;
import org.docx4j.wml.R;
import org.docx4j.wml.Text;

import info.hncy.word.generator.support.ProcessorUtils;
import info.hncy.word.generator.support.TextBoxHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 变量替换处理器 —— 将 {@code ${key}} 占位符替换为文本值。
 *
 * <p>从 {@link ProcessingContext} 中读取 textData，构建变量映射，
 * 然后在文档树中执行替换。跳过 {@code ${@key}} 图片占位符（留给 ImageReplaceProcessor）。</p>
 */
public class VariableReplaceProcessor implements DocumentProcessor {

    private static final Logger log = LoggerFactory.getLogger(VariableReplaceProcessor.class);

    private static final Pattern TOKEN_PATTERN = Pattern.compile("\\$\\{([^}@][^}]*)\\}");
    private static final ObjectFactory FACTORY = new ObjectFactory();

    /**
     * 执行变量替换。
     *
     * <p>从上下文中读取文本数据，构建变量映射，然后遍历文档树
     * （正文 + 页眉/页脚 + 文本框）替换所有 {@code ${key}} 占位符。
     * 跳过 {@code ${@key}} 图片占位符。</p>
     *
     * @param pkg     文档包
     * @param context 处理上下文
     */
    @Override
    public void process(WordprocessingMLPackage pkg, ProcessingContext context) {
        Map<String, String> mappings = buildMappings(context.getOthers());
        for (JaxbXmlPart<?> part : ProcessorUtils.collectParts(pkg)) {
            replaceTextInTree(part.getJaxbElement(), mappings);
        }
    }

    /**
     * 从原始数据中构建文本变量映射。
     *
     * <p>保留 String、Number 和 Boolean 类型的值；null 转为空字符串；
     * 其他类型（Map/List/PictureData）记录 warn 日志并跳过。</p>
     *
     * @param data 原始数据
     * @return 变量名 → 文本值映射
     */
    private static Map<String, String> buildMappings(Map<String, Object> data) {
        Map<String, String> mappings = new LinkedHashMap<String, String>();
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            Object val = entry.getValue();
            if (val == null) {
                mappings.put(entry.getKey(), "");
            } else if (val instanceof String) {
                mappings.put(entry.getKey(), (String) val);
            } else if (val instanceof Number) {
                mappings.put(entry.getKey(), String.valueOf(val));
            } else if (val instanceof Boolean) {
                mappings.put(entry.getKey(), String.valueOf(val));
            } else {
                log.warn("变量 [{}] 的值类型为 {}，不支持文本替换，已跳过。"
                        + "List/Map 请用于区块模式，PictureData 请用于 ${@key}",
                        entry.getKey(), val.getClass().getSimpleName());
            }
        }
        return mappings;
    }

    private static void replaceTextInTree(Object node, Map<String, String> mappings) {
        Object o = XmlUtils.unwrap(node);

        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            replaceTextInTree(txbx, mappings);
        }

        if (o instanceof R) {
            replaceInRun((R) o, mappings);
            for (Object item : ((R) o).getContent()) {
                for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(item)) {
                    replaceTextInTree(txbx, mappings);
                }
            }
            return;
        }

        if (o instanceof ContentAccessor) {
            for (Object child : new ArrayList<Object>(((ContentAccessor) o).getContent())) {
                replaceTextInTree(child, mappings);
            }
        }
    }

    private static void replaceInRun(R run, Map<String, String> mappings) {
        boolean changed = false;
        for (Object item : run.getContent()) {
            Object val = XmlUtils.unwrap(item);
            if (val instanceof Text) {
                Text text = (Text) val;
                String v = text.getValue();
                if (v != null && v.contains("${")) {
                    Matcher m = TOKEN_PATTERN.matcher(v);
                    StringBuffer sb = new StringBuffer();
                    while (m.find()) {
                        String key = m.group(1);
                        if (mappings.containsKey(key)) {
                            m.appendReplacement(sb, Matcher.quoteReplacement(mappings.get(key)));
                        } else {
                            m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
                        }
                    }
                    m.appendTail(sb);
                    String newText = sb.toString();
                    if (!newText.equals(v)) {
                        text.setValue(newText);
                        changed = true;
                    }
                }
            }
        }
        if (changed) {
            rebuildRunContent(run);
        }
    }

    /**
     * 重建 run 内容：将 Text 节点中的换行符（\n、\r、\f）拆分为 w:br 元素。
     *
     * @param run 要重建的 run
     */
    private static void rebuildRunContent(R run) {
        List<Object> newContent = new ArrayList<Object>();

        for (Object item : run.getContent()) {
            Object val = XmlUtils.unwrap(item);
            if (val instanceof Text) {
                String textValue = ((Text) val).getValue();
                if (textValue == null) continue;
                String[] lines = textValue.split("\\r\\n|\\r|\\n|\\f", -1);
                for (int i = 0; i < lines.length; i++) {
                    if (i > 0) {
                        newContent.add(FACTORY.createBr());
                    }
                    if (!lines[i].isEmpty()) {
                        Text t = FACTORY.createText();
                        t.setValue(lines[i]);
                        t.setSpace("preserve");
                        newContent.add(t);
                    }
                }
            } else {
                newContent.add(item);
            }
        }

        run.getContent().clear();
        run.getContent().addAll(newContent);
    }
}
