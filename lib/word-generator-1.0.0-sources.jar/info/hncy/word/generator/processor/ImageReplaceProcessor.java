package info.hncy.word.generator.processor;

import info.hncy.word.generator.DocumentProcessor;
import info.hncy.word.generator.ProcessingContext;

import org.docx4j.XmlUtils;
import org.docx4j.wml.CTTxbxContent;
import org.docx4j.dml.wordprocessingDrawing.Inline;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.JaxbXmlPart;
import org.docx4j.openpackaging.parts.WordprocessingML.BinaryPartAbstractImage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.Drawing;
import org.docx4j.wml.ObjectFactory;
import org.docx4j.wml.P;
import org.docx4j.wml.R;
import org.docx4j.wml.SectPr;
import org.docx4j.wml.Text;

import info.hncy.word.generator.model.PictureData;
import info.hncy.word.generator.support.ProcessorUtils;
import info.hncy.word.generator.support.TextBoxHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 图片替换处理器 —— 将 {@code ${@key}} 占位符替换为实际图片（如电子签名）。
 *
 * <p>工作原理：在 {@code variableReplace} 之后调用。variableReplace 对没有文本映射值的
 * {@code ${@key}} 会原样保留（花括号不丢失），本处理器再在文档对象模型层面找到这些
 * {@code ${@key}}，将其所在的 run 替换为包含 {@code w:drawing}（内联图片）的 run。</p>
 *
 * <p>支持同一 run 内多个图片占位符、占位符与普通文本混排（自动拆分为多个 run）。</p>
 *
 * <p>支持图片自适应页面尺寸（fitWidth/fitHeight/contain/cover），根据页面可用区域（页面尺寸减去边距）自动等比缩放。
 * fitWidth/fitHeight/contain 始终适配到页面约束（小于时拉伸，大于时缩小），保持宽高比。
 * cover 强制拉伸填满页面，不保持比例。</p>
 *
 * <p>调用时机：必须在 {@code variableReplace} 之后（variableReplace 会反序列化 XML，
 * 之前的对象引用全部失效）。</p>
 */
public class ImageReplaceProcessor implements DocumentProcessor {

    private static final Logger log = LoggerFactory.getLogger(ImageReplaceProcessor.class);

    /** 图片占位符正则（实例字段，由构造函数注入） */
    private final Pattern imageToken;

    private static final ObjectFactory FACTORY = new ObjectFactory();

    /** 图片数据：key（不含包装）→ PictureData，从 context 获取 */
    private Map<String, PictureData> images;

    /** 用于生成唯一的 docPr id / rel id（随机起始值降低与文档已有 ID 冲突的概率） */
    private final AtomicLong idCounter = new AtomicLong(10000 + new java.util.Random().nextInt(90000));

    /** 本次替换计数 */
    private int replacedCount;

    /**
     * 使用默认配置（${@key} 语法）。
     */
    public ImageReplaceProcessor() {
        this(Pattern.compile("\\$\\{@([^}]+)\\}"));
    }

    /**
     * @param imageToken 图片占位符正则（group(1) 为 key）
     */
    public ImageReplaceProcessor(Pattern imageToken) {
        this.imageToken = imageToken;
    }

    /**
     * 执行图片替换。
     *
     * <p>从上下文中获取图片池，然后遍历文档（正文 + 页眉/页脚 + 文本框），
     * 将所有 {@code ${@key}} 占位符替换为对应的内联图片。</p>
     *
     * @param pkg     文档包
     * @param context 处理上下文（包含图片池）
     * @throws Exception 图片创建或文档处理过程中的错误
     */
    @Override
    public void process(WordprocessingMLPackage pkg, ProcessingContext context) throws Exception {
        this.images = context.getImages();
        replace(pkg);
    }

    /**
     * 对整份文档（正文 + 页眉/页脚）执行图片替换。
     *
     * @return 成功替换的图片数量
     */
    public int replace(WordprocessingMLPackage pkg) throws Exception {
        replacedCount = 0;
        MainDocumentPart mainPart = pkg.getMainDocumentPart();
        for (JaxbXmlPart<?> part : ProcessorUtils.collectParts(pkg)) {
            processPart(part, mainPart);
        }
        return replacedCount;
    }

    // ------------------------------------------------------------------
    // 核心替换逻辑
    // ------------------------------------------------------------------

    private void processPart(JaxbXmlPart<?> part, MainDocumentPart mainPart) throws Exception {
        List<P> paragraphs = new ArrayList<P>();
        collectParagraphs(part.getJaxbElement(), paragraphs);

        for (P p : paragraphs) {
            // 每次替换后段落结构可能变化（run 被拆分），需重新扫描
            boolean changed = true;
            while (changed) {
                changed = replaceOnceInParagraph(p, part, mainPart);
            }
        }
    }

    /**
     * 在段落中找到第一个可替换的 {@code ${@key}} 并替换。
     *
     * @return true 表示做了一次替换（调用方需重新扫描段落）
     */
    private boolean replaceOnceInParagraph(P p, JaxbXmlPart<?> targetPart, MainDocumentPart mainPart) throws Exception {
        List<RunCtx> ctxList = new ArrayList<RunCtx>();
        collectRunCtx(p, null, ctxList);

        for (RunCtx ctx : ctxList) {
            String text = ctx.text.getValue();
            if (text == null) {
                continue;
            }
            Matcher m = imageToken.matcher(text);
            if (!m.find()) {
                continue;
            }
            String key = m.group(1);
            PictureData picData = images.get(key);
            if (picData == null) {
                log.warn("图片占位符 ${@" + key + "} 未找到对应的图片数据，保留原文");
                continue;
            }

            int matchStart = m.start();
            int matchEnd = m.end();
            String before = text.substring(0, matchStart);
            String after = text.substring(matchEnd);

            List<Object> parent = ctx.runParent;
            int runIdx = ProcessorUtils.indexOfRun(parent, ctx.run);
            if (runIdx < 0) {
                continue;
            }

            // 空图片（null / new byte[0]）→ 删除占位符，不插入图片
            if (picData.getImageBytes().length == 0) {
                int insertPos = runIdx + 1;
                if (!after.isEmpty()) {
                    R afterRun = ProcessorUtils.createTextRun(after, ctx.run.getRPr());
                    parent.add(insertPos, afterRun);
                }
                if (before.isEmpty()) {
                    removeTextFromRun(ctx.run, ctx.text);
                    if (!ProcessorUtils.runHasVisibleContent(ctx.run)) {
                        parent.remove(runIdx);
                    }
                } else {
                    ctx.text.setValue(before);
                }
                replacedCount++;
                return true;
            }

            // 创建图片 inline + drawing
            Drawing drawing;
            try {
                drawing = createDrawing(targetPart, mainPart, key, picData);
            } catch (Exception e) {
                throw new RuntimeException("图片 [" + key + "] 创建失败: " + e.getMessage(), e);
            }

            // 图片 run
            R imgRun = FACTORY.createR();
            imgRun.getContent().add(drawing);

            // 从后往前插入，保证位置正确
            int insertPos = runIdx + 1;

            if (!after.isEmpty()) {
                R afterRun = ProcessorUtils.createTextRun(after, ctx.run.getRPr());
                parent.add(insertPos, afterRun);
            }

            parent.add(insertPos, imgRun);

            // 处理原始 run：修改文本为 before 部分（或移除）
            if (before.isEmpty()) {
                // 从 run 中移除该 Text 节点
                removeTextFromRun(ctx.run, ctx.text);
                if (!ProcessorUtils.runHasVisibleContent(ctx.run)) {
                    parent.remove(runIdx);
                }
            } else {
                ctx.text.setValue(before);
            }

            replacedCount++;
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // 图片创建
    // ------------------------------------------------------------------

    private Drawing createDrawing(JaxbXmlPart<?> targetPart, MainDocumentPart mainPart,
                                  String key, PictureData picData) throws Exception {
        byte[] bytes = picData.getImageBytes();
        BinaryPartAbstractImage imagePart = BinaryPartAbstractImage.createImagePart(
                mainPart.getPackage(), targetPart, bytes);
        long id1 = idCounter.getAndIncrement();
        int id2 = (int) idCounter.getAndIncrement();
        Inline inline = imagePart.createImageInline(key + "." + picData.getFormat(), key, id1, id2, false);

        // 应用自定义尺寸
        long[] emuSize = computeEmuSize(picData, mainPart);
        if (emuSize != null) {
            inline.getExtent().setCx(emuSize[0]);
            inline.getExtent().setCy(emuSize[1]);
        }

        Drawing drawing = FACTORY.createDrawing();
        drawing.getAnchorOrInline().add(inline);
        return drawing;
    }

    /** 像素到 EMU 的转换系数，1 像素 = 9525 EMU（96 DPI） */
    private static final int PX_TO_EMU = 9525;

    /** twip 到 EMU 的转换系数：1 twip = 635 EMU（1 EMU = 1/914400 英寸，1 twip = 1/1440 英寸） */
    private static final int TWIP_TO_EMU = 635;

    /** 默认页面宽度（A4，twips）—— docx4j createPackage 的默认值 */
    private static final long DEFAULT_PAGE_W_TWIPS = 11907;

    /** 默认页面高度（A4，twips）—— docx4j createPackage 的默认值 */
    private static final long DEFAULT_PAGE_H_TWIPS = 16839;

    /** 默认页面边距（1 英寸 = 1440 twips） */
    private static final long DEFAULT_MARGIN_TWIPS = 1440;

    /**
     * 计算图片最终渲染尺寸（EMU），96 DPI。
     *
     * <p>优先级：宽/高设定 &gt; 缩放比例 &gt; 自适应模式 &gt; 原图大小。</p>
     *
     * @param picData  图片数据
     * @param mainPart 文档主体部分（用于读取页面尺寸）
     * @return [cx, cy] EMU；无自定义尺寸返回 null（使用原图大小）
     */
    private long[] computeEmuSize(PictureData picData, MainDocumentPart mainPart) throws Exception {
        byte[] imageBytes = picData.getImageBytes();
        if (imageBytes.length == 0) return null;

        Integer width = picData.getWidth();
        Integer height = picData.getHeight();
        Double scale = picData.getScale();
        int fitMode = picData.getFitMode();

        if (width != null || height != null) {
            int[] orig = decodeSize(imageBytes);
            int finalW, finalH;
            if (width != null && height != null) {
                finalW = width;
                finalH = height;
            } else if (width != null) {
                finalW = width;
                finalH = (int) ((long) width * orig[1] / orig[0]);
            } else {
                finalH = height;
                finalW = (int) ((long) height * orig[0] / orig[1]);
            }
            return new long[]{ (long) finalW * PX_TO_EMU, (long) finalH * PX_TO_EMU };
        }

        if (scale != null) {
            int[] orig = decodeSize(imageBytes);
            int w = Math.max(1, (int) (orig[0] * scale));
            int h = Math.max(1, (int) (orig[1] * scale));
            return new long[]{ (long) w * PX_TO_EMU, (long) h * PX_TO_EMU };
        }

        if (fitMode != 0) {
            int[] orig = decodeSize(imageBytes);
            long origWEmu = (long) orig[0] * PX_TO_EMU;
            long origHEmu = (long) orig[1] * PX_TO_EMU;

            long[] avail = getPageAvailableEmu(mainPart);
            double widthRatio = (double) avail[0] / origWEmu;
            double heightRatio = (double) avail[1] / origHEmu;

            double ratio;
            switch (fitMode) {
                case 1: ratio = widthRatio; break;
                case 2: ratio = heightRatio; break;
                case 3: ratio = Math.min(widthRatio, heightRatio); break;
                case 4:
                    return new long[]{ avail[0], avail[1] };
                default: return null;
            }

            long finalW = Math.max(1, (long) (origWEmu * ratio));
            long finalH = Math.max(1, (long) (origHEmu * ratio));
            return new long[]{ finalW, finalH };
        }

        return null;
    }

    /**
     * 解码图片字节数据获取原始尺寸。
     *
     * @param imageBytes 图片字节数组
     * @return [宽, 高]
     */
    private int[] decodeSize(byte[] imageBytes) throws Exception {
        java.awt.image.BufferedImage img = javax.imageio.ImageIO.read(
                new java.io.ByteArrayInputStream(imageBytes));
        if (img == null) {
            throw new IllegalArgumentException("无法解码图片数据：格式不支持或数据已损坏");
        }
        return new int[]{ img.getWidth(), img.getHeight() };
    }

    /**
     * 获取页面可用区域的尺寸（EMU）。
     *
     * <p>可用区域 = 页面尺寸 - 边距。从文档的 SectionProperties 读取；
     * 未设置时使用 A4 纸张（11906×16838 twips）和 1 英寸默认边距。</p>
     *
     * @param mainPart 文档主体部分
     * @return [可用宽度, 可用高度]，单位 EMU
     */
    private long[] getPageAvailableEmu(MainDocumentPart mainPart) {
        long pageW = DEFAULT_PAGE_W_TWIPS;
        long pageH = DEFAULT_PAGE_H_TWIPS;
        long marginLeft = DEFAULT_MARGIN_TWIPS;
        long marginRight = DEFAULT_MARGIN_TWIPS;
        long marginTop = DEFAULT_MARGIN_TWIPS;
        long marginBottom = DEFAULT_MARGIN_TWIPS;

        SectPr sectPr = mainPart.getJaxbElement().getBody().getSectPr();
        if (sectPr != null) {
            if (sectPr.getPgSz() != null) {
                if (sectPr.getPgSz().getW() != null) pageW = sectPr.getPgSz().getW().longValue();
                if (sectPr.getPgSz().getH() != null) pageH = sectPr.getPgSz().getH().longValue();
            }
            if (sectPr.getPgMar() != null) {
                SectPr.PgMar mar = sectPr.getPgMar();
                if (mar.getLeft() != null) marginLeft = mar.getLeft().longValue();
                if (mar.getRight() != null) marginRight = mar.getRight().longValue();
                if (mar.getTop() != null) marginTop = mar.getTop().longValue();
                if (mar.getBottom() != null) marginBottom = mar.getBottom().longValue();
            }
        }

        long availW = Math.max(0, (pageW - marginLeft - marginRight) * TWIP_TO_EMU);
        long availH = Math.max(0, (pageH - marginTop - marginBottom) * TWIP_TO_EMU);
        return new long[]{ availW, availH };
    }

    // ------------------------------------------------------------------
    // 文本 / Run 工具
    // ------------------------------------------------------------------

    /** 从 run 的 content 中移除指定的 Text 节点（兼容 JAXBElement 包装） */
    private void removeTextFromRun(R run, Text target) {
        for (Iterator<Object> it = run.getContent().iterator(); it.hasNext(); ) {
            if (XmlUtils.unwrap(it.next()) == target) {
                it.remove();
                return;
            }
        }
    }

    // ------------------------------------------------------------------
    // 遍历：收集段落 / 收集 (Run, Text, parentContent) 上下文
    // ------------------------------------------------------------------

    private static void collectParagraphs(Object node, List<P> out) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof P) {
            out.add((P) o);
        }
        if (o instanceof ContentAccessor) {
            for (Object child : new ArrayList<Object>(((ContentAccessor) o).getContent())) {
                collectParagraphs(child, out);
            }
        }
        if (o instanceof R) {
            for (Object child : ((R) o).getContent()) {
                for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(child)) {
                    collectParagraphs(txbx, out);
                }
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            collectParagraphs(txbx, out);
        }
    }

    /**
     * RunCtx：记录 Text 节点、所属 Run、以及 Run 所在的父内容列表
     * （用于在父列表中替换/插入 run）。
     */
    private static class RunCtx {
        R run;
        Text text;
        List<Object> runParent;
    }

    private static void collectRunCtx(Object node, List<Object> runParent, List<RunCtx> out) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof R) {
            R r = (R) o;
            for (Object item : r.getContent()) {
                Object val = XmlUtils.unwrap(item);
                if (val instanceof Text) {
                    RunCtx ctx = new RunCtx();
                    ctx.run = r;
                    ctx.text = (Text) val;
                    ctx.runParent = runParent;
                    out.add(ctx);
                }
            }
            return;
        }
        if (o instanceof ContentAccessor) {
            List<Object> content = ((ContentAccessor) o).getContent();
            for (Object child : new ArrayList<Object>(content)) {
                collectRunCtx(child, content, out);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            collectRunCtx(txbx, txbx.getContent(), out);
        }
    }
}
