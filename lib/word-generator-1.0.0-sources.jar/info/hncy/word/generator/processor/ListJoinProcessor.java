package info.hncy.word.generator.processor;

import info.hncy.word.generator.DocumentProcessor;
import info.hncy.word.generator.ProcessingContext;

import org.docx4j.XmlUtils;
import org.docx4j.wml.CTTxbxContent;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.JaxbXmlPart;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.P;
import org.docx4j.wml.R;
import org.docx4j.wml.RPr;
import org.docx4j.wml.Text;

import info.hncy.word.generator.model.PictureData;
import info.hncy.word.generator.support.ProcessorUtils;
import info.hncy.word.generator.support.TextBoxHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.Image;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 列表展开处理器 —— 将 {@code ${%name}} 或 {@code ${%name:separator}} 占位符
 * 展开为列表项，用分隔符连接。
 *
 * <p>默认分隔符为中文顿号「、」，可通过 {@code ${%name:sep}} 自定义。</p>
 *
 * <p>列表项类型：</p>
 * <ul>
 *   <li><b>文本/数字</b>：直接拼接为字符串，替换占位符。</li>
 *   <li><b>图片</b>（byte[]）：展开为多个 {@code ${@key}} 图片占位符，
 *       由后续 {@link ImageReplaceProcessor} 完成实际图片插入。</li>
 * </ul>
 *
 * <p><b>调用时机：</b>在 {@link RunMergeProcessor} 和
 * {@link BlockPairProcessor} 之后、{@link VariableReplaceProcessor} 之前。</p>
 */
public class ListJoinProcessor implements DocumentProcessor {

    private static final Logger log = LoggerFactory.getLogger(ListJoinProcessor.class);

    private static final String BUILTIN_DEFAULT_SEP = "、";

    /** 列表占位符正则（实例字段，由构造函数注入） */
    private final Pattern listToken;

    /** 图片占位符开始部分，如 "${@" */
    private final String imgOpen;

    /** 图片占位符结束部分，如 "}" */
    private final String imgClose;

    private Map<String, Object> data;
    private Map<String, Object> originalData;
    /** 图片池引用（从 context 获取，用于写入列表展开中生成的图片条目） */
    private Map<String, PictureData> images;
    private String defaultSep;
    private int imgCounter;

    /**
     * 使用默认占位符语法（${...}）。
     */
    public ListJoinProcessor() {
        this(
                Pattern.compile("\\$\\{%([^}]+)\\}"), "${@", "}");
    }

    /**
     * @param listToken  列表占位符正则（group(1) 为 name 或 name:sep）
     * @param imgOpen    图片占位符开始部分，如 "${@"
     * @param imgClose   图片占位符结束部分，如 "}"
     */
    public ListJoinProcessor(Pattern listToken, String imgOpen, String imgClose) {
        this.listToken = listToken;
        this.imgOpen = imgOpen;
        this.imgClose = imgClose;
        this.imgCounter = 0;
    }

    /**
     * 执行列表展开。
     *
     * <p>从上下文中获取数据和图片池，然后遍历文档（正文 + 页眉/页脚 + 文本框），
     * 将所有 {@code ${%name}} 或 {@code ${%name:sep}} 占位符展开为列表项。</p>
     *
     * @param pkg     文档包
     * @param context 处理上下文（包含数据和图片池）
     * @throws Exception 处理过程中的错误
     */
    @Override
    public void process(WordprocessingMLPackage pkg, ProcessingContext context) throws Exception {
        this.data = context.getOthers();
        this.originalData = context.getOriginalData();
        this.images = context.getImages();
        this.defaultSep = context.getSeparator() != null ? context.getSeparator() : BUILTIN_DEFAULT_SEP;
        process(pkg);
    }

    /**
     * 扫描并展开文档中所有 {@code ${%name}} 占位符。
     *
     * @return 展开的列表占位符数量
     */
    public int process(WordprocessingMLPackage pkg) throws Exception {
        if (data == null) {
            throw new IllegalStateException("请先调用 process(pkg, context) 设置数据");
        }
        imgCounter = 0;
        int count = 0;
        for (JaxbXmlPart<?> part : ProcessorUtils.collectParts(pkg)) {
            count += processPart(part.getJaxbElement());
        }
        return count;
    }

    // ------------------------------------------------------------------
    // 核心逻辑
    // ------------------------------------------------------------------

    private int processPart(Object node) throws Exception {
        int count = 0;
        List<Object> children = getChildren(node);
        if (children == null) {
            return 0;
        }
        for (Object child : new ArrayList<Object>(children)) {
            Object unwrapped = XmlUtils.unwrap(child);
            if (unwrapped instanceof P) {
                count += processParagraph((P) unwrapped);
            } else if (unwrapped instanceof ContentAccessor) {
                count += processPart(unwrapped);
            }
            for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(unwrapped)) {
                count += processPart(txbx);
            }
        }
        return count;
    }

    private int processParagraph(P p) throws Exception {
        int count = 0;

        int maxIterations = 1000;
        boolean changed = true;
        while (changed && maxIterations-- > 0) {
            changed = false;
            List<RunCtx> ctxList = new ArrayList<RunCtx>();
            collectRunCtx(p, null, ctxList);
            for (RunCtx ctx : ctxList) {
                String text = ctx.text.getValue();
                if (text == null) continue;
                Matcher m = listToken.matcher(text);
                boolean found = m.find();
                if (!found) continue;

                String inner = m.group(1);
                String[] parsed = parseToken(inner);
                String name = parsed[0];
                String sep = parsed[1];
                List<?> list = getList(name);
                if (list == null) continue;

                if (hasImages(list)) {
                    expandImageList(p, ctx, m, list, sep);
                } else {
                    replaceWithText(ctx, m, list, sep);
                }
                count++;
                changed = true;
                break;
            }
        }
        return count;
    }

    // ------------------------------------------------------------------
    // 文本列表展开
    // ------------------------------------------------------------------

    private void replaceWithText(RunCtx ctx, Matcher m, List<?> list, String sep) {
        List<String> items = new ArrayList<String>();
        for (Object item : list) {
            if (item != null) items.add(String.valueOf(item));
        }
        String joined = join(items, sep);
        String text = ctx.text.getValue();
        String newText = text.substring(0, m.start()) + joined + text.substring(m.end());
        ctx.text.setValue(newText);
    }

    // ------------------------------------------------------------------
    // 图片列表展开
    // ------------------------------------------------------------------

    private void expandImageList(P p, RunCtx ctx, Matcher m, List<?> list, String sep)
            throws Exception {
        String text = ctx.text.getValue();
        String before = text.substring(0, m.start());
        String after = text.substring(m.end());
        RPr rpr = ctx.run.getRPr();

        List<Object> parent = ctx.runParent;
        int runIdx = ProcessorUtils.indexOfRun(parent, ctx.run);
        if (runIdx < 0) return;

        List<Object> newRuns = new ArrayList<Object>();

        if (!before.isEmpty()) {
            newRuns.add(ProcessorUtils.createTextRun(before, rpr));
        }

        boolean first = true;
        for (Object item : list) {
            PictureData picData;
            if (item instanceof PictureData) {
                picData = (PictureData) item;
                if (picData.getImageBytes().length == 0) continue;
            } else if (item instanceof byte[]) {
                byte[] bytes = (byte[]) item;
                if (bytes.length == 0) continue;
                picData = PictureData.of(bytes);
            } else if (item instanceof Image) {
                try {
                    picData = PictureData.of((Image) item);
                } catch (Exception ex) {
                    log.warn("列表项图片解析失败，已跳过: {}", ex.getMessage());
                    continue;
                }
            } else if (item instanceof File) {
                try {
                    picData = PictureData.of((File) item);
                } catch (Exception ex) {
                    log.warn("列表项图片解析失败，已跳过: {}", ex.getMessage());
                    continue;
                }
            } else {
                continue;
            }

            if (!first) {
                newRuns.add(ProcessorUtils.createTextRun(sep, rpr));
            }
            first = false;

            String imgKey = "_lj_" + (++imgCounter);
            images.put(imgKey, picData);
            newRuns.add(ProcessorUtils.createTextRun(imgOpen + imgKey + imgClose, rpr));
        }

        if (!after.isEmpty()) {
            newRuns.add(ProcessorUtils.createTextRun(after, rpr));
        }

        parent.remove(runIdx);
        for (int i = newRuns.size() - 1; i >= 0; i--) {
            parent.add(runIdx, newRuns.get(i));
        }
    }

    // ------------------------------------------------------------------
    // 解析与查找
    // ------------------------------------------------------------------

    /** 解析 inner（正则 group(1)）：{@code name} 或 {@code name:sep} */
    private String[] parseToken(String inner) {
        int colon = inner.indexOf(':');
        if (colon >= 0) {
            return new String[]{inner.substring(0, colon), inner.substring(colon + 1)};
        }
        return new String[]{inner, defaultSep};
    }

    @SuppressWarnings("unchecked")
    private List<?> getList(String name) {
        if (data.containsKey(name)) {
            Object val = data.get(name);
            if (val == null) {
                log.warn("列表占位符 ${%" + name + "} 的值为 null，保留原文");
                return null;
            }
            if (val instanceof List) return (List<?>) val;
            log.warn("列表占位符 ${%" + name + "} 的值类型为 {}，不是 List，已跳过", val.getClass().getSimpleName());
            return null;
        }
        if (originalData != null) {
            Object val = resolveFromOriginal(name);
            if (val instanceof List) return (List<?>) val;
            if (val != null) {
                log.warn("列表占位符 ${%" + name + "} 的值类型为 {}，不是 List，已跳过", val.getClass().getSimpleName());
                return null;
            }
        }
        log.warn("列表占位符 ${%" + name + "} 未找到对应的数据，保留原文");
        return null;
    }

    @SuppressWarnings("unchecked")
    private Object resolveFromOriginal(String path) {
        if (originalData.containsKey(path)) {
            return originalData.get(path);
        }
        if (!path.contains(".")) return null;
        String[] parts = path.split("\\.");
        Object current = originalData;
        for (String part : parts) {
            if (current instanceof Map) {
                current = ((Map<String, Object>) current).get(part);
            } else {
                return null;
            }
        }
        return current;
    }

    private static boolean hasImages(List<?> list) {
        for (Object item : list) {
            if (item instanceof byte[] || item instanceof PictureData
                    || item instanceof Image || item instanceof File) return true;
        }
        return false;
    }

    private static String join(List<String> items, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(items.get(i));
        }
        return sb.toString();
    }

    private static void collectRunCtx(Object node, List<Object> runParent, List<RunCtx> out) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof R) {
            R r = (R) o;
            for (Object item : r.getContent()) {
                Object val = XmlUtils.unwrap(item);
                if (val instanceof Text) {
                    RunCtx ctx = new RunCtx();
                    ctx.run = r;
                    ctx.text = (Text) val;
                    ctx.runParent = runParent;
                    out.add(ctx);
                }
            }
            return;
        }
        if (o instanceof ContentAccessor) {
            List<Object> content = ((ContentAccessor) o).getContent();
            for (Object child : new ArrayList<Object>(content)) {
                collectRunCtx(child, content, out);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            collectRunCtx(txbx, txbx.getContent(), out);
        }
    }

    private static List<Object> getChildren(Object node) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof ContentAccessor) {
            return ((ContentAccessor) o).getContent();
        }
        return null;
    }

    private static class RunCtx {
        R run;
        Text text;
        List<Object> runParent;
    }
}
