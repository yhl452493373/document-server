package info.hncy.word.generator;

import info.hncy.word.generator.processor.BlockPairProcessor;
import info.hncy.word.generator.processor.ImageReplaceProcessor;
import info.hncy.word.generator.processor.ListJoinProcessor;
import info.hncy.word.generator.processor.RunMergeProcessor;
import info.hncy.word.generator.processor.VariableReplaceProcessor;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 文档处理管线 —— 按顺序执行一组 {@link DocumentProcessor}。
 *
 * <p>默认管线包含五个处理器：RunMerge → BlockPair → ListJoin → VariableReplace → ImageReplace。</p>
 *
 * <p>扩展用法：</p>
 * <pre>
 * DocumentPipeline pipeline = DocumentPipeline.createDefault()
 *     .add(3, new MyCustomProcessor());
 *
 * byte[] result = new WordGenerator(null, pipeline)
 *     .generate(template, data);
 * </pre>
 */
public class DocumentPipeline {

    private static final Logger log = LoggerFactory.getLogger(DocumentPipeline.class);

    private final List<DocumentProcessor> processors;

    /**
     * 创建空管线（不含任何处理器）。
     */
    public DocumentPipeline() {
        this.processors = new ArrayList<DocumentProcessor>();
    }

    /**
     * 创建包含指定处理器列表的管线。
     *
     * @param processors 处理器列表（按执行顺序排列）
     */
    public DocumentPipeline(List<DocumentProcessor> processors) {
        this.processors = new ArrayList<DocumentProcessor>(processors);
    }

    /**
     * 创建包含默认处理器的管线。
     *
     * <p>默认处理器顺序：RunMerge → BlockPair → ListJoin → VariableReplace → ImageReplace。</p>
     *
     * @return 配置好默认处理器的管线实例
     */
    public static DocumentPipeline createDefault() {
        DocumentPipeline pipeline = new DocumentPipeline();
        pipeline.add(new RunMergeProcessor());
        pipeline.add(new BlockPairProcessor());
        pipeline.add(new ListJoinProcessor());
        pipeline.add(new VariableReplaceProcessor());
        pipeline.add(new ImageReplaceProcessor());
        return pipeline;
    }

    /**
     * 在管线末尾添加处理器。
     *
     * @param processor 要添加的处理器
     * @return 当前管线实例（支持链式调用）
     */
    public DocumentPipeline add(DocumentProcessor processor) {
        processors.add(processor);
        return this;
    }

    /**
     * 在指定位置插入处理器。
     *
     * @param index     插入位置（0-based）
     * @param processor 要插入的处理器
     * @return 当前管线实例（支持链式调用）
     */
    public DocumentPipeline add(int index, DocumentProcessor processor) {
        processors.add(index, processor);
        return this;
    }

    /**
     * 按顺序执行管线中的所有处理器。
     *
     * <p>每个处理器执行前会输出 debug 日志；如果某个处理器抛出异常，
     * 会记录 error 日志（含处理器类名）后原样抛出。</p>
     *
     * @param pkg     文档包
     * @param context 处理上下文
     * @throws Exception 某个处理器执行失败时抛出
     */
    public void execute(WordprocessingMLPackage pkg, ProcessingContext context) throws Exception {
        for (int i = 0; i < processors.size(); i++) {
            DocumentProcessor processor = processors.get(i);
            try {
                log.debug("执行处理器 [{}/{}]: {}", i + 1, processors.size(), processor.getClass().getSimpleName());
                processor.process(pkg, context);
            } catch (Exception e) {
                log.error("处理器 [{}] 执行失败: {}", processor.getClass().getSimpleName(), e.getMessage(), e);
                throw e;
            }
        }
    }

    /**
     * 获取管线中的处理器列表（只读视图）。
     *
     * @return 处理器列表
     */
    public List<DocumentProcessor> getProcessors() {
        return Collections.unmodifiableList(processors);
    }
}
