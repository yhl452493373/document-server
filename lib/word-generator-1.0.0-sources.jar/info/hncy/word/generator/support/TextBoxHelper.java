package info.hncy.word.generator.support;

import org.docx4j.XmlUtils;
import org.docx4j.dml.Graphic;
import org.docx4j.dml.GraphicData;
import org.docx4j.dml.wordprocessingDrawing.Anchor;
import org.docx4j.dml.wordprocessingDrawing.Inline;
import org.docx4j.mce.AlternateContent;
import org.docx4j.vml.CTTextbox;
import org.docx4j.wml.CTTxbxContent;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.Drawing;
import org.docx4j.wml.Pict;
import org.docx4j.wml.R;
import org.docx4j.wml.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * 从 Drawing（DrawingML）和 Pict（VML）节点中提取文本框内容。
 *
 * <p>Word 中文本框不实现 {@code ContentAccessor}，导致基于 ContentAccessor 的遍历
 * 无法进入文本框内部。本工具类提供统一的提取方法，让各处理器可以递归处理文本框中的占位符。</p>
 */
public final class TextBoxHelper {

    private TextBoxHelper() {
    }

    /**
     * 从节点中提取所有文本框内容。
     *
     * @param node 已 unwrap 的 JAXB 对象
     * @return 文本框内容列表（可能为空，不会为 null）
     */
    public static List<CTTxbxContent> getTextBoxContents(Object node) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof Drawing) {
            return extractFromDrawing((Drawing) o);
        }
        if (o instanceof Pict) {
            return extractFromPict((Pict) o);
        }
        if (o instanceof AlternateContent) {
            return extractFromAlternateContent((AlternateContent) o);
        }
        return java.util.Collections.emptyList();
    }

    /**
     * 从 DrawingML Drawing 节点中提取文本框内容。
     *
     * @param drawing Drawing 节点
     * @return 文本框内容列表
     */
    private static List<CTTxbxContent> extractFromDrawing(Drawing drawing) {
        List<CTTxbxContent> result = new ArrayList<CTTxbxContent>();
        List<Object> anchorOrInline = drawing.getAnchorOrInline();
        if (anchorOrInline == null) {
            return result;
        }
        for (Object ai : anchorOrInline) {
            Object unwrapped = XmlUtils.unwrap(ai);
            Graphic graphic = null;
            if (unwrapped instanceof Anchor) {
                graphic = ((Anchor) unwrapped).getGraphic();
            } else if (unwrapped instanceof Inline) {
                graphic = ((Inline) unwrapped).getGraphic();
            }
            if (graphic == null) {
                continue;
            }
            CTTxbxContent txbx = extractFromGraphic(graphic);
            if (txbx != null) {
                result.add(txbx);
            }
        }
        return result;
    }

    /**
     * 从 Graphic 节点中提取 WordprocessingShape 的文本框内容。
     *
     * @param graphic Graphic 节点
     * @return 文本框内容，未找到返回 null
     */
    private static CTTxbxContent extractFromGraphic(Graphic graphic) {
        GraphicData data = graphic.getGraphicData();
        if (data == null) {
            return null;
        }
        org.docx4j.com.microsoft.schemas.office.word.x2010.wordprocessingShape.CTWordprocessingShape shape = null;

        Object wpsRaw = XmlUtils.unwrap(data.getWordprocessingShape());
        if (wpsRaw instanceof org.docx4j.com.microsoft.schemas.office.word.x2010.wordprocessingShape.CTWordprocessingShape) {
            shape = (org.docx4j.com.microsoft.schemas.office.word.x2010.wordprocessingShape.CTWordprocessingShape) wpsRaw;
        } else {
            List<Object> anyList = data.getAny();
            if (anyList != null) {
                for (Object item : anyList) {
                    Object u = XmlUtils.unwrap(item);
                    if (u instanceof org.docx4j.com.microsoft.schemas.office.word.x2010.wordprocessingShape.CTWordprocessingShape) {
                        shape = (org.docx4j.com.microsoft.schemas.office.word.x2010.wordprocessingShape.CTWordprocessingShape) u;
                        break;
                    }
                }
            }
        }
        if (shape != null) {
            org.docx4j.com.microsoft.schemas.office.word.x2010.wordprocessingShape.CTTextboxInfo txbxInfo = shape.getTxbx();
            if (txbxInfo != null) {
                return txbxInfo.getTxbxContent();
            }
        }
        return null;
    }

    /**
     * 从 VML Pict 节点中提取文本框内容。
     *
     * @param pict Pict 节点
     * @return 文本框内容列表
     */
    private static List<CTTxbxContent> extractFromPict(Pict pict) {
        List<CTTxbxContent> result = new ArrayList<CTTxbxContent>();
        for (Object item : pict.getAnyAndAny()) {
            Object unwrapped = XmlUtils.unwrap(item);
            if (unwrapped instanceof CTTextbox) {
                CTTxbxContent content = ((CTTextbox) unwrapped).getTxbxContent();
                if (content != null) {
                    result.add(content);
                }
            }
            List<javax.xml.bind.JAXBElement<?>> shapeElements = null;
            if (unwrapped instanceof org.docx4j.vml.CTShape) {
                shapeElements = ((org.docx4j.vml.CTShape) unwrapped).getEGShapeElements();
            } else if (unwrapped instanceof org.docx4j.vml.CTRect) {
                shapeElements = ((org.docx4j.vml.CTRect) unwrapped).getEGShapeElements();
            }
            if (shapeElements != null) {
                for (javax.xml.bind.JAXBElement<?> elem : shapeElements) {
                    Object elemVal = XmlUtils.unwrap(elem);
                    if (elemVal instanceof CTTextbox) {
                        CTTxbxContent content = ((CTTextbox) elemVal).getTxbxContent();
                        if (content != null) {
                            result.add(content);
                        }
                    }
                }
            }
        }
        return result;
    }

    /**
     * 从 AlternateContent 节点中提取文本框内容（遍历 Choice 和 Fallback）。
     *
     * @param ac AlternateContent 节点
     * @return 文本框内容列表
     */
    private static List<CTTxbxContent> extractFromAlternateContent(AlternateContent ac) {
        List<CTTxbxContent> result = new ArrayList<CTTxbxContent>();
        List<AlternateContent.Choice> choices = ac.getChoice();
        if (choices != null) {
            for (AlternateContent.Choice choice : choices) {
                List<Object> anyItems = choice.getAny();
                if (anyItems != null) {
                    for (Object item : anyItems) {
                        result.addAll(getTextBoxContents(item));
                    }
                }
            }
        }
        AlternateContent.Fallback fallback = ac.getFallback();
        if (fallback != null) {
            List<Object> fallbackItems = fallback.getAny();
            if (fallbackItems != null) {
                for (Object item : fallbackItems) {
                    result.addAll(getTextBoxContents(item));
                }
            }
        }
        return result;
    }

    // ==================== 文本框内 run 合并 ====================

    /**
     * 遍历文档树，合并所有文本框段落内的 run。
     *
     * <p>VariablePrepare 只处理正文/页眉页脚中的段落，不会进入文本框。
     * 如果用户在 Word 中给文本框文字加了格式（加粗、颜色等），占位符会被拆成多个 run，
     * 导致后续正则无法匹配。本方法在 VariablePrepare 之后调用，确保文本框内的 run 也被合并。</p>
     */
    public static void mergeRunsInTextBoxes(Object node) {
        Object o = XmlUtils.unwrap(node);

        for (CTTxbxContent txbx : getTextBoxContents(o)) {
            mergeRunsInTxbxContent(txbx);
        }

        if (o instanceof Drawing || o instanceof Pict || o instanceof AlternateContent) {
            return;
        }

        if (o instanceof R) {
            for (Object item : ((R) o).getContent()) {
                for (CTTxbxContent txbx : getTextBoxContents(item)) {
                    mergeRunsInTxbxContent(txbx);
                }
            }
            return;
        }

        if (o instanceof ContentAccessor) {
            for (Object child : ((ContentAccessor) o).getContent()) {
                mergeRunsInTextBoxes(child);
            }
        }
    }

    private static void mergeRunsInTxbxContent(CTTxbxContent txbx) {
        for (Object child : txbx.getContent()) {
            Object o = XmlUtils.unwrap(child);
            if (o instanceof org.docx4j.wml.P) {
                mergeRunsInParagraph((org.docx4j.wml.P) o);
            }
        }
    }

    private static void mergeRunsInParagraph(org.docx4j.wml.P p) {
        List<Object> content = p.getContent();

        int firstRunIdx = -1;
        int lastRunIdx = -1;
        for (int i = 0; i < content.size(); i++) {
            if (XmlUtils.unwrap(content.get(i)) instanceof R) {
                if (firstRunIdx == -1) firstRunIdx = i;
                lastRunIdx = i;
            }
        }

        if (firstRunIdx == -1 || firstRunIdx == lastRunIdx) {
            return;
        }

        StringBuilder sb = new StringBuilder();
        List<Object> nonRunElements = new ArrayList<Object>();
        R firstRun = (R) XmlUtils.unwrap(content.get(firstRunIdx));
        for (int i = firstRunIdx; i <= lastRunIdx; i++) {
            Object val = XmlUtils.unwrap(content.get(i));
            if (val instanceof R) {
                sb.append(extractTextValue((R) val));
            } else {
                nonRunElements.add(content.get(i));
            }
        }

        R merged = new R();
        merged.setRPr(XmlUtils.deepCopy(firstRun.getRPr()));
        if (sb.length() > 0) {
            Text t = new Text();
            t.setValue(sb.toString());
            t.setSpace("preserve");
            merged.getContent().add(t);
        }

        List<Object> newContent = new ArrayList<Object>();
        for (int i = 0; i < firstRunIdx; i++) {
            newContent.add(content.get(i));
        }
        newContent.add(merged);
        for (Object elem : nonRunElements) {
            newContent.add(elem);
        }
        for (int i = lastRunIdx + 1; i < content.size(); i++) {
            newContent.add(content.get(i));
        }

        content.clear();
        content.addAll(newContent);
    }

    private static String extractTextValue(R run) {
        StringBuilder sb = new StringBuilder();
        for (Object item : run.getContent()) {
            Object val = XmlUtils.unwrap(item);
            if (val instanceof Text) {
                String v = ((Text) val).getValue();
                if (v != null) sb.append(v);
            }
        }
        return sb.toString();
    }
}
