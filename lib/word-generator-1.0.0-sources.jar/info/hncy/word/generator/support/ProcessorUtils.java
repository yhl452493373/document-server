package info.hncy.word.generator.support;

import org.docx4j.XmlUtils;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.JaxbXmlPart;
import org.docx4j.openpackaging.parts.Part;
import org.docx4j.openpackaging.parts.WordprocessingML.EndnotesPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FooterPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FootnotesPart;
import org.docx4j.openpackaging.parts.WordprocessingML.HeaderPart;
import org.docx4j.wml.ObjectFactory;
import org.docx4j.wml.R;
import org.docx4j.wml.RPr;
import org.docx4j.wml.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * 处理器共享的工具方法集合。
 *
 * <p>提供文档部件收集、run 操作、文本节点创建等通用功能，
 * 供各处理器实现类复用。</p>
 */
public final class ProcessorUtils {

    private static final ObjectFactory FACTORY = new ObjectFactory();

    private ProcessorUtils() {
    }

    /**
     * 收集文档包中需要处理的部件（正文 + 页眉 + 页脚 + 脚注 + 尾注）。
     *
     * @param pkg 文档包
     * @return 需要处理的部件列表
     */
    public static List<JaxbXmlPart<?>> collectParts(WordprocessingMLPackage pkg) {
        List<JaxbXmlPart<?>> list = new ArrayList<JaxbXmlPart<?>>();
        list.add(pkg.getMainDocumentPart());
        for (Part part : pkg.getParts().getParts().values()) {
            if (part instanceof HeaderPart || part instanceof FooterPart
                    || part instanceof FootnotesPart || part instanceof EndnotesPart) {
                list.add((JaxbXmlPart<?>) part);
            }
        }
        return list;
    }

    /**
     * 判断 run 是否包含可见内容（非空文本、图片、换行等）。
     *
     * <p>用于在删除占位符文本后判断 run 是否应该保留。</p>
     *
     * @param run 要检查的 run
     * @return true 表示 run 包含可见内容
     */
    public static boolean runHasVisibleContent(R run) {
        for (Object item : run.getContent()) {
            Object val = XmlUtils.unwrap(item);
            if (val instanceof Text) {
                String v = ((Text) val).getValue();
                if (v != null && !v.isEmpty()) {
                    return true;
                }
            } else {
                return true;
            }
        }
        return false;
    }

    /**
     * 用给定文本创建一个新的 run，可选复制源 run 的格式。
     *
     * @param text      文本内容
     * @param sourceRPr 源格式（RPr），null 表示不设置格式
     * @return 包含指定文本的新 run
     */
    public static R createTextRun(String text, RPr sourceRPr) {
        R run = FACTORY.createR();
        if (sourceRPr != null) {
            run.setRPr(XmlUtils.deepCopy(sourceRPr));
        }
        Text t = FACTORY.createText();
        t.setValue(text);
        t.setSpace("preserve");
        run.getContent().add(t);
        return run;
    }

    /**
     * 在父内容列表中按 identity 查找 run 的索引。
     *
     * <p>使用 {@code ==} 比较（identity），而非 equals。</p>
     *
     * @param parent 父内容列表
     * @param target 要查找的 run
     * @return run 的索引（0-based），未找到返回 -1
     */
    public static int indexOfRun(List<Object> parent, R target) {
        for (int i = 0; i < parent.size(); i++) {
            if (XmlUtils.unwrap(parent.get(i)) == target) {
                return i;
            }
        }
        return -1;
    }
}
