package info.hncy.word.generator.support;

import org.docx4j.XmlUtils;
import org.docx4j.model.datastorage.migration.VariablePrepare;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.JaxbXmlPart;
import org.docx4j.openpackaging.parts.WordprocessingML.EndnotesPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FooterPart;
import org.docx4j.openpackaging.parts.WordprocessingML.HeaderPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FootnotesPart;
import org.docx4j.utils.SingleTraversalUtilVisitorCallback;
import org.docx4j.wml.CTTxbxContent;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.P;
import org.docx4j.wml.R;
import org.docx4j.wml.Text;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 模板提取工具 —— 从 docx 模板中提取文本内容和占位符变量名。
 *
 * <p>用途：</p>
 * <ul>
 *   <li>提取文档全部文本（{@link #extractText}）</li>
 *   <li>扫描模板中所有 {@code ${...}} 占位符变量（{@link #extractVariables}）</li>
 * </ul>
 */
public final class TemplateExtractor {

    private static final Pattern VARIABLE_PATTERN = Pattern.compile("\\$\\{([^}]+)\\}");

    private TemplateExtractor() {
    }

    // ==================== 提取文本内容 ====================

    /**
     * 从字节数组模板提取全部文本内容。
     *
     * @param templateBytes docx 模板字节数组
     * @return 文档中所有文本（段落以换行分隔）
     * @throws Exception 模板解析失败
     */
    public static String extractText(byte[] templateBytes) throws Exception {
        WordprocessingMLPackage pkg = TemplateLoader.load(templateBytes);
        return extractText(pkg);
    }

    /**
     * 从文件对象模板提取全部文本内容。
     *
     * @param file docx 模板文件
     * @return 文档中所有文本（段落以换行分隔）
     * @throws Exception 模板解析失败
     */
    public static String extractText(File file) throws Exception {
        WordprocessingMLPackage pkg = TemplateLoader.load(file);
        return extractText(pkg);
    }

    /**
     * 从文件路径模板提取全部文本内容。
     *
     * @param path docx 模板文件路径
     * @return 文档中所有文本（段落以换行分隔）
     * @throws Exception 模板解析失败
     */
    public static String extractText(String path) throws Exception {
        WordprocessingMLPackage pkg = TemplateLoader.load(path);
        return extractText(pkg);
    }

    /**
     * 从文档包提取全部文本内容。
     *
     * <p>先执行 run 合并，确保被 Word 拆散的占位符能完整识别。
     * 遍历正文、页眉、页脚、文本框中的所有段落。</p>
     *
     * <p><b>注意：</b>此方法会就地修改传入的 pkg（执行 run 合并和文本框合并），
     * 如需保留原始文档结构，请先深拷贝。</p>
     *
     * @param pkg 文档包
     * @return 文档中所有文本（段落以换行分隔）
     * @throws Exception 处理失败
     */
    public static String extractText(WordprocessingMLPackage pkg) throws Exception {
        VariablePrepare.prepare(pkg);

        SingleTraversalUtilVisitorCallback runJoiner =
                new SingleTraversalUtilVisitorCallback(
                        new VariablePrepare.TraversalUtilParagraphVisitor());

        List<JaxbXmlPart<?>> parts = ProcessorUtils.collectParts(pkg);
        for (JaxbXmlPart<?> part : parts) {
            if (part instanceof HeaderPart || part instanceof FooterPart
                    || part instanceof FootnotesPart || part instanceof EndnotesPart) {
                runJoiner.walkJAXBElements(part.getJaxbElement());
            }
            TextBoxHelper.mergeRunsInTextBoxes(part.getJaxbElement());
        }

        List<String> paragraphs = new ArrayList<String>();
        for (JaxbXmlPart<?> part : parts) {
            extractTextFromNode(part.getJaxbElement(), paragraphs);
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < paragraphs.size(); i++) {
            if (i > 0) sb.append("\n");
            sb.append(paragraphs.get(i));
        }
        return sb.toString();
    }

    // ==================== 提取占位符变量 ====================

    /**
     * 从字节数组模板提取所有 {@code ${...}} 占位符变量。
     *
     * @param templateBytes docx 模板字节数组
     * @return 变量名集合（已去除类型前缀，闭合标签已过滤）
     * @throws Exception 模板解析失败
     */
    public static Set<String> extractVariables(byte[] templateBytes) throws Exception {
        WordprocessingMLPackage pkg = TemplateLoader.load(templateBytes);
        return extractVariables(pkg);
    }

    /**
     * 从文件对象模板提取所有 {@code ${...}} 占位符变量。
     *
     * @param file docx 模板文件
     * @return 变量名集合（已去除类型前缀，闭合标签已过滤）
     * @throws Exception 模板解析失败
     */
    public static Set<String> extractVariables(File file) throws Exception {
        WordprocessingMLPackage pkg = TemplateLoader.load(file);
        return extractVariables(pkg);
    }

    /**
     * 从文件路径模板提取所有 {@code ${...}} 占位符变量。
     *
     * @param path docx 模板文件路径
     * @return 变量名集合（已去除类型前缀，闭合标签已过滤）
     * @throws Exception 模板解析失败
     */
    public static Set<String> extractVariables(String path) throws Exception {
        WordprocessingMLPackage pkg = TemplateLoader.load(path);
        return extractVariables(pkg);
    }

    /**
     * 从文档包提取所有 {@code ${...}} 占位符变量。
     *
     * <p>先执行 run 合并，确保被 Word 拆散的占位符能完整识别。
     * 扫描正文、页眉、页脚、文本框中的所有 Text 节点。</p>
     *
     * <p>返回的变量名已去除类型前缀（{@code ?}、{@code @}、{@code %}），
     * 闭合标签（{@code /xxx}）已过滤：</p>
     * <ul>
     *   <li>{@code "name"} — 普通变量</li>
     *   <li>{@code "show"} — 条件/循环/映射区块（原 {@code ?show}）</li>
     *   <li>{@code "members"} — 列表展开（原 {@code %members}）</li>
     *   <li>{@code "signature"} — 图片（原 {@code @signature}）</li>
     * </ul>
     *
     * <p><b>注意：</b>此方法会就地修改传入的 pkg（执行 run 合并和文本框合并），
     * 如需保留原始文档结构，请先深拷贝。</p>
     *
     * @param pkg 文档包
     * @return 变量名集合（去重）
     * @throws Exception 处理失败
     */
    public static Set<String> extractVariables(WordprocessingMLPackage pkg) throws Exception {
        VariablePrepare.prepare(pkg);

        SingleTraversalUtilVisitorCallback runJoiner =
                new SingleTraversalUtilVisitorCallback(
                        new VariablePrepare.TraversalUtilParagraphVisitor());

        List<JaxbXmlPart<?>> parts = ProcessorUtils.collectParts(pkg);
        for (JaxbXmlPart<?> part : parts) {
            if (part instanceof HeaderPart || part instanceof FooterPart
                    || part instanceof FootnotesPart || part instanceof EndnotesPart) {
                runJoiner.walkJAXBElements(part.getJaxbElement());
            }
            TextBoxHelper.mergeRunsInTextBoxes(part.getJaxbElement());
        }

        Set<String> variables = new LinkedHashSet<String>();
        for (JaxbXmlPart<?> part : parts) {
            collectVariablesFromNode(part.getJaxbElement(), variables);
        }
        return variables;
    }

    // ==================== 内部方法 ====================

    private static void collectVariablesFromNode(Object node, Set<String> variables) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof P) {
            List<Text> texts = new ArrayList<Text>();
            collectTextNodes(o, texts);
            for (Text t : texts) {
                if (t.getValue() != null) {
                    Matcher m = VARIABLE_PATTERN.matcher(t.getValue());
                    while (m.find()) {
                        String varName = m.group(1);
                        if (!varName.isEmpty() && varName.charAt(0) != '/') {
                            if (varName.charAt(0) == '?' || varName.charAt(0) == '@' || varName.charAt(0) == '%') {
                                varName = varName.substring(1);
                            }
                            variables.add(varName);
                        }
                    }
                }
            }
            return;
        }
        if (o instanceof ContentAccessor) {
            for (Object child : ((ContentAccessor) o).getContent()) {
                collectVariablesFromNode(child, variables);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            collectVariablesFromNode(txbx, variables);
        }
    }

    private static void extractTextFromNode(Object node, List<String> paragraphs) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof P) {
            List<Text> texts = new ArrayList<Text>();
            collectTextNodes(o, texts);
            StringBuilder sb = new StringBuilder();
            for (Text t : texts) {
                if (t.getValue() != null) {
                    sb.append(t.getValue());
                }
            }
            paragraphs.add(sb.toString());
            return;
        }
        if (o instanceof ContentAccessor) {
            for (Object child : ((ContentAccessor) o).getContent()) {
                extractTextFromNode(child, paragraphs);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            extractTextFromNode(txbx, paragraphs);
        }
    }

    private static void collectTextNodes(Object node, List<Text> texts) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof R) {
            for (Object item : ((R) o).getContent()) {
                Object val = XmlUtils.unwrap(item);
                if (val instanceof Text) {
                    texts.add((Text) val);
                }
                for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(item)) {
                    collectTextNodes(txbx, texts);
                }
            }
            return;
        }
        if (o instanceof ContentAccessor) {
            for (Object child : ((ContentAccessor) o).getContent()) {
                collectTextNodes(child, texts);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            collectTextNodes(txbx, texts);
        }
    }
}
