package info.hncy.word.generator.support;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * 模板加载工具 —— 读取 docx 文件并预处理（边框名称归一化）。
 *
 * <p>加载时自动将 OOXML 2007+ 的 {@code w:start}/{@code w:end} 边框元素
 * 替换为 docx4j 能识别的 {@code w:left}/{@code w:right}，避免垂直边框丢失。</p>
 */
public final class TemplateLoader {

    private TemplateLoader() {
    }

    /**
     * 从字节数组加载模板。
     *
     * @param docxBytes docx 文件字节数组
     * @return 加载后的文档包
     * @throws IllegalArgumentException 如果字节数组为 null 或为空
     * @throws Exception                解析失败
     */
    public static WordprocessingMLPackage load(byte[] docxBytes) throws Exception {
        if (docxBytes == null) throw new IllegalArgumentException("模板字节数组不能为 null");
        if (docxBytes.length == 0) throw new IllegalArgumentException("模板字节数组不能为空");
        byte[] normalized = normalizeBorders(docxBytes);
        return WordprocessingMLPackage.load(new ByteArrayInputStream(normalized));
    }

    /**
     * 从文件对象加载模板。
     *
     * @param file docx 文件对象
     * @return 加载后的文档包
     * @throws IllegalArgumentException 如果文件为 null、不存在或不是有效文件
     * @throws Exception                解析失败
     */
    public static WordprocessingMLPackage load(File file) throws Exception {
        if (file == null) throw new IllegalArgumentException("模板文件不能为 null");
        if (!file.exists()) throw new IllegalArgumentException("模板文件不存在: " + file.getAbsolutePath());
        if (!file.isFile()) throw new IllegalArgumentException("不是有效文件: " + file.getAbsolutePath());
        return load(readFile(file));
    }

    /**
     * 从文件路径加载模板。
     *
     * @param path docx 文件路径
     * @return 加载后的文档包
     * @throws IllegalArgumentException 如果路径为 null 或文件不存在
     * @throws Exception                解析失败
     */
    public static WordprocessingMLPackage load(String path) throws Exception {
        if (path == null) throw new IllegalArgumentException("模板路径不能为 null");
        return load(new File(path));
    }

    // ==================== 边框名称归一化 ====================

    /**
     * 将 docx 内 XML 中的 {@code w:start}/{@code w:end} 边框元素替换为 {@code w:left}/{@code w:right}。
     *
     * <p>OOXML 2007+ 用 {@code w:start}/{@code w:end} 表示左/右边框（支持 RTL），
     * 但 docx4j 的 JAXB 模型只识别 {@code w:left}/{@code w:right}，
     * 加载时会静默丢弃 {@code w:start}/{@code w:end}，导致垂直边框丢失。</p>
     */
    private static byte[] normalizeBorders(byte[] docxBytes) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(docxBytes));
        try {
            ZipOutputStream zos = new ZipOutputStream(baos);
            try {
                ZipEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    byte[] content = readEntry(zis);
                    String name = entry.getName();
                    if (name.endsWith(".xml") && !name.endsWith("/numbering.xml") && !name.equals("numbering.xml")) {
                        String xml = new String(content, "UTF-8");
                        if (xml.contains("<w:start ") || xml.contains("<w:end ")) {
                            xml = xml.replace("<w:start ", "<w:left ");
                            xml = xml.replace("</w:start>", "</w:left>");
                            xml = xml.replace("<w:end ", "<w:right ");
                            xml = xml.replace("</w:end>", "</w:right>");
                            content = xml.getBytes("UTF-8");
                        }
                    }
                    ZipEntry newEntry = new ZipEntry(name);
                    zos.putNextEntry(newEntry);
                    zos.write(content);
                    zos.closeEntry();
                }
            } finally {
                zos.close();
            }
        } finally {
            zis.close();
        }
        return baos.toByteArray();
    }

    private static byte[] readEntry(ZipInputStream zis) throws Exception {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] tmp = new byte[4096];
        int n;
        while ((n = zis.read(tmp)) > 0) {
            buf.write(tmp, 0, n);
        }
        return buf.toByteArray();
    }

    private static byte[] readFile(File file) throws Exception {
        return java.nio.file.Files.readAllBytes(file.toPath());
    }
}
