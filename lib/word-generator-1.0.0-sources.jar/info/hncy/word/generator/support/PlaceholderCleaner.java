package info.hncy.word.generator.support;

import org.docx4j.XmlUtils;
import org.docx4j.model.datastorage.migration.VariablePrepare;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.JaxbXmlPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FooterPart;
import org.docx4j.openpackaging.parts.WordprocessingML.HeaderPart;
import org.docx4j.openpackaging.parts.WordprocessingML.EndnotesPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FootnotesPart;
import org.docx4j.utils.SingleTraversalUtilVisitorCallback;
import org.docx4j.wml.CTTxbxContent;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.R;
import org.docx4j.wml.Text;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 占位符清理工具 —— 清除文档中所有残留的 {@code ${...}} 占位符。
 *
 * <p>适用于模板处理完成后、转 PDF 前，清除未匹配的占位符。</p>
 */
public final class PlaceholderCleaner {

    private static final Pattern ALL_PLACEHOLDERS = Pattern.compile("\\$\\{[^}]*\\}");

    private PlaceholderCleaner() {
    }

    /**
     * 清除字节数组模板中的残留占位符。
     *
     * @param template docx 模板字节数组
     * @return 清除占位符后的文档字节数组
     * @throws Exception 模板解析或处理过程中的错误
     */
    public static byte[] clear(byte[] template) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板字节数组不能为 null");
        WordprocessingMLPackage pkg = TemplateLoader.load(template);
        return clear(pkg);
    }

    /**
     * 清除文件模板中的残留占位符。
     *
     * @param template docx 模板文件
     * @return 清除占位符后的文档字节数组
     * @throws Exception 模板解析或处理过程中的错误
     */
    public static byte[] clear(File template) throws Exception {
        if (template == null) throw new IllegalArgumentException("模板文件不能为 null");
        WordprocessingMLPackage pkg = TemplateLoader.load(template);
        return clear(pkg);
    }

    /**
     * 清除文件路径模板中的残留占位符。
     *
     * @param path docx 模板文件路径
     * @return 清除占位符后的文档字节数组
     * @throws Exception 模板解析或处理过程中的错误
     */
    public static byte[] clear(String path) throws Exception {
        if (path == null) throw new IllegalArgumentException("模板路径不能为 null");
        return clear(new File(path));
    }

    /**
     * 清除文档包中所有残留的 {@code ${...}} 占位符。
     *
     * <p>处理流程：先合并 run → 合并文本框内 run → 遍历清除所有 Text 节点中的占位符。</p>
     *
     * @param pkg 文档包
     * @return 清除占位符后的文档字节数组
     * @throws Exception 处理过程中的错误
     */
    public static byte[] clear(WordprocessingMLPackage pkg) throws Exception {
        VariablePrepare.prepare(pkg);

        SingleTraversalUtilVisitorCallback runJoiner =
                new SingleTraversalUtilVisitorCallback(
                        new VariablePrepare.TraversalUtilParagraphVisitor());

        List<JaxbXmlPart<?>> parts = ProcessorUtils.collectParts(pkg);
        for (JaxbXmlPart<?> part : parts) {
            if (part instanceof HeaderPart || part instanceof FooterPart
                    || part instanceof FootnotesPart || part instanceof EndnotesPart) {
                runJoiner.walkJAXBElements(part.getJaxbElement());
            }
            TextBoxHelper.mergeRunsInTextBoxes(part.getJaxbElement());
        }

        for (JaxbXmlPart<?> part : parts) {
            clearInNode(part.getJaxbElement());
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        pkg.save(baos);
        return baos.toByteArray();
    }

    private static void clearInNode(Object node) {
        Object o = XmlUtils.unwrap(node);
        if (o instanceof R) {
            R run = (R) o;
            for (Iterator<Object> it = run.getContent().iterator(); it.hasNext(); ) {
                Object item = it.next();
                Object val = XmlUtils.unwrap(item);
                if (val instanceof Text) {
                    Text text = (Text) val;
                    String v = text.getValue();
                    if (v != null) {
                        String cleaned = ALL_PLACEHOLDERS.matcher(v).replaceAll("");
                        if (cleaned.isEmpty()) {
                            it.remove();
                        } else {
                            text.setValue(cleaned);
                        }
                    }
                }
            }
            for (Object item : run.getContent()) {
                for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(item)) {
                    clearInNode(txbx);
                }
            }
            return;
        }
        if (o instanceof ContentAccessor) {
            for (Object child : new ArrayList<Object>(((ContentAccessor) o).getContent())) {
                clearInNode(child);
            }
        }
        for (CTTxbxContent txbx : TextBoxHelper.getTextBoxContents(o)) {
            clearInNode(txbx);
        }
    }
}
